# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 10:19:23 2018

@author: admin
"""

# =============================================================================
# data=10;
# def scopeTest():
#    data=100;
#    print("function scope :",data);
#     
# print("main scope",data);
# scopeTest();
# 
# =============================================================================
data=10;
def scopeTest():
   global data
   data=100;
   return data;

print("function scope",scopeTest());    
print("main scope",data);
