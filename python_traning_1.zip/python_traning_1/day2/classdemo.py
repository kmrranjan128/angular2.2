# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 10:45:28 2018

@author: admin
"""

class PC:
    
    os="Window Server 2016"
    
    
    @staticmethod
    def osInfo():
        print("Operating System used is %s" %(PC.os));
        
    
    def __init__(self,no,ipaddr,vlan):
        
        print(type(PC));
        self.__pcNo=no;
        self.ipAddress=ipaddr;# this in not a private 
        self.__vlan=vlan;# __ sign as private
        #print(self.__pcNo);
        
#create instance
        #setter method
    def setVlan(self,status): # selt == this
        self.__vlan=status;
   
    #getter method
    def getIpAddress(self):
        return self.ipAddress;
    def getPCNo(self):
        return self.__pcNo;
    def getVlan(self):
        return self.__vlan;
    def info():
        print("method");
    
    
class Locker:
     def __init__(self,id):
         self.lockeId=id;
         
         
def info():
    print("method1");         
         
#def getLockerId(self):
#return self.lockerId;         
    
    
"""
pc1=PC(1,'127.0.0.1',True);
print("IP Address %s"%(pc1.ipAddress)); 

pc1.setVlan(False);

print(PC.os)

print("PC No=%d\n IP Address=%s\n VLAN status=%s"%(pc1.getPCNo(),pc1.getIpAddress(),pc1.getVlan()))

PC.osInfo();
"""




