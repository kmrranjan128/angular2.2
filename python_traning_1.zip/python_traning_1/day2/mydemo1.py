# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 16:26:08 2018

@author: admin
"""

import pymysql;

class CRUDDemo:
    def __init__(self):
        self.conn=pymysql.connect(host="localhost",user="root",passwd="welcome@1",db="svs_python_db");



# =============================================================================
# def createConnection():
#     conn=pymysql.connect(host="localhost",user="root",passwd="welcome@1",db="svs_python_db");
#     return conn;
# =============================================================================

    def addTestCaseInfo(self,data):
        cursor=self.conn.cursor();
        print("Cursor ready");  
        print(data);
        try:
            cursor.execute("""insert into testcaseresults values ('%d','%s','%d')""" %(data[0],data[1],data[2]))
            self.conn.commit();
        except pymysql.Error as e:
            print("Exception occured",e);
            self.conn.rollback();
        finally:
            cursor.close();
            self.conn.close();

            
    #cursor.close();
    



def fetchBytestCaseId(self,id):
    #conn=createConnection()
    cursor=self.conn.cursor();
    cursor.execute("""select * from testcaseresults where tcno='%d'"""%(id))
    rows=cursor.fetchall();
    cursor.clase();
    self.conn.close();
    return rows;


def backupTable(self):
    query="""SELECT *from testcaseresults INTO OUTFILE 'querydump.cvs' FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n'"""
    self.conn.connect();
    cursor=self.conn.cursor();
    cursor.execue(query);
    cursor.close();
    self.conn.close();

curdObject=CRUDDemo();
curdObject.backupTable();

rows=fetchBytestCaseId(1001)
for row in rows:
    print(row);

# =============================================================================
# curdObj=CRUDDemo();
# curdObj.addTestCaseInfo([9827,'REQ101',1]);
# =============================================================================


# =============================================================================
# rows=fetchBytestCaseId(1001)
# for row in rows:
#     print(row);
# 
# =============================================================================
