# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 13:01:53 2018

@author: admin
"""

#control statements
import random;
genData=0;
for i in range(1,10):
   # print(i);
    genData=random.randint(1,500);
    if(genData>100):
        print(genData,end='\t');
 
