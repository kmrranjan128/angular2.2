# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 16:18:51 2018

@author: admin
"""

customerInfo=(32456,'Anand','2/2/1990','Chennai')
print(customerInfo);





#list and tuple
customerArray=[(32456,'Anand','2/2/1990','Chennai'),
               (32457,'Anand1','2/2/1991','Chennai1'),
               (32458,'Anand2','2/2/1992','Chennai2'),
               (32459,'Anand3','2/2/1993','Chennai3')];
                   
customerArray.append((32451,'Anand4','2/2/1994','Chennai4'));
print(customerArray);


t = ('275', '54000', '0.0', '5000.0', '0.0')
lst = list(t)
print(lst)
lst[0] = '300'
t = tuple(lst)
print(t);
