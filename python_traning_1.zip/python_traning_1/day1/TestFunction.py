# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 09:48:31 2018

@author: admin
"""



from datetime import date;
import sys;
sys.path.append("D:/python_traning_1/day2")
#from functiondemo import check,fundTransfer;

#check(date.today().strftime("%d/%m/%Y"));

fundTransfer(12345,34324,5000);

if __name__ == '__main__':
    print('This program is being run by itself');
else:
    print("I am beign imported form another module");

    
    