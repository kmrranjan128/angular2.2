# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 12:11:01 2018

@author: admin
"""

#hex from conversion
memoryAddress=255;
hexData=hex(memoryAddress);
print(hexData);
print("Memory Address in hex from %x"%(memoryAddress));

#complex Number
real=56;
imaginary=45;
print(complex(real,imaginary));

# binary to decimal
print(int('10010',2));
#decimal to binary
print(bin(10))