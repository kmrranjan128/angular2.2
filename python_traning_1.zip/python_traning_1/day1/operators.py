# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 12:37:30 2018

@author: admin
"""
#floor operator
basevalue=67;
score=112;
print(score/basevalue);
print(score//basevalue);

# exponent operstor
print(basevalue**2);#square


