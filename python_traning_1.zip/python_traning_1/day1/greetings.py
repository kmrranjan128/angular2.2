# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# starts first program 
"""
start up 
code 
in python
"""
print("welcome to Shriram");
comment="Learning python is \
awesome"
#check type of the variable
print(type(comment)); # output :- <class 'str'>
#read first name from user
firstname=input("Enter your Name : ");
age=int(input("Enter Age : "));
#check type of the variable
print(type(age)); # output :- <class 'str'>


#format and print
print("First Name= %s comments as %s "%(firstname,comment));


update=age+10;
print(update);
