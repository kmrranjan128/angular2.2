import {Injectable} from "@angular/core";
import {Http} from "@angular/http";
import 'rxjs';
@Injectable()
export class UserService{

    constructor(private http:Http){

    }

    getUserService()
    {
        return this.http.get('https://restcountries.eu/rest/v2/all').flatMap((data)=>data.json());

    }

    getOpecData(){
        return this.http.get('').flatMap((data)=>data.json());
    }

    getuserInfo(){
         return this.http.get('https://restcountries.eu/rest/v2/all').flatMap((data)=>data.json());
    }


}