import {Directive,ElementRef} from "@angular/core";


@Directive({
    selector:'[highlight]'
})

export class HighLightComponent{

    constructor(private el:ElementRef){
        if(el.nativeElement.nodeName==='H1')
        {

            el.nativeElement.className='h1style';

        }

        if(el.nativeElement.nodeName==='p'){

            el.nativeElement.nodeName.style.backgroundColor='lightblue';

        }

    }


}
