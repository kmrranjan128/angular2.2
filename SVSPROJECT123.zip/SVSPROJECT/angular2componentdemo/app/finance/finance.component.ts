import {Component, OnInit} from "@angular/core"
import {OPECService} from "../services/mockService";


@Component({
    templateUrl:'./app/finance/finance.component.html',
    styleUrls:['./app/finance/finance.component.css']


})

export class FinancialComponent implements OnInit{


private finData:any=[];
    constructor(private opecService:OPECService){

    }

    ngOnInit(){

        this.opecService.getOPECData().then(response=>{

            response.forEach((obj)=> {
                this.finData.push(obj)

            })


           // this.finData.push(response);
            //console.log(this.finData);
        })

    }



}