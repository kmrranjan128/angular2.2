
import {Component} from "@angular/core";

@Component({
    templateUrl:'./app/forms/form.login.component.html',
    styleUrls:['./app/forms/form.login.component.css']
})
export class LoginComponent{

}