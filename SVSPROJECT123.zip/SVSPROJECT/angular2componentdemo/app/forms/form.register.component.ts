import {Component} from "@angular/core";
import {FormControl, FormBuilder, FormGroup, Validator, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {Customer} from "../model/customerModel";


@Component({
    templateUrl:'./app/forms/form.register.component.html',
    styleUrls:['./app/forms/form.register.component.css']
})
export class RegisterComponent{
    private customer:Customer

    private registerForm:FormGroup;
    private firstName:FormControl;
    private lastName:FormControl;
    private dob:FormControl;
    private email:FormControl;

    constructor(private formBuilder:FormBuilder,private router:Router){

        this.firstName=new FormControl(Validators.minLength(5),Validators.maxLength(25), Validators.required);
        this.lastName=new FormControl(Validators.minLength(5),Validators.maxLength(25), Validators.required);
        this.dob=new FormControl(Validators.required);
        this.email=new FormControl(Validators.required);

        this.registerForm=formBuilder.group([
        this.firstName,
        this.lastName,
        this.dob,
        this.email
])

    }

    save():void{
        console.log(this.registerForm.value);
        this.customer=this.registerForm.value;
        this.router.navigate(["/login"]);

    }

}