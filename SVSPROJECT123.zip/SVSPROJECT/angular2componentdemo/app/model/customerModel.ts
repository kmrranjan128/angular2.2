
export class Customer{
private firstName:string;
private lastName:string;
private dob:string;
private email:string;


//setter

set setFisrtName(value:string){
    this.firstName=value;
}


set setLastName(value:string){
    this.lastName=value;
}

set setDOB(value:string){
    this.dob=value;
}

set setEmail(value:string){
    this.email=value;
}

// getter

get getFisrtname():string{
    return this.firstName;
}

get getLastName():string{
    return this.lastName;
}
get getDOB():string{
    return this.dob;
}
get getEmail():string{
    return this.email;
}
}