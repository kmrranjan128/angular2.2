export class OPEC{
    private date:string;
    private oilPrice:number;

    constructor(date:string,price:number){
        this.date=date;
        this.oilPrice=price;

    }
    get getdate():string{
        return this.date;
    }

    get getOilPrice():number{
        return this.oilPrice;
    }
}