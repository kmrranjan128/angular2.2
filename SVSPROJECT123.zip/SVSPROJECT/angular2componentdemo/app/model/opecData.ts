import {OPEC} from "./opecModel";


export const OPECDATA:OPEC[]=[new OPEC("12/12/2017",60.12),
new OPEC("15/12/2017",66.12),
    new OPEC("16/12/2017",67.17),
    new OPEC("17/12/2017",68.12),
    new OPEC("18/12/2017",69.43),
    new OPEC("19/12/2017",70.11),
    new OPEC("20/12/2017",61.32)

]