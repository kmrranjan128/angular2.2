depositeApp.service('CountryDataService',['$http',function ($http) {
var countryList=function () {
    return $http({
        method:'GET',
        dataType:"jsonp",
        header:{
            'Content-Type':'application/x-ww-form-urlencoded'
        },
        url:'https://restcountries.eu/rest/v2/all'
    }).then((function (info) {
        console.log("resolved");
        return info;
    }));
}
// closures
return{
    CountryDataServiceObj:countryList

};
}])