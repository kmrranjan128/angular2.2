import {FileLogger} from "./loggerDemo";

var logger:FileLogger=new FileLogger();
logger.writeToLog("Exception occurred");