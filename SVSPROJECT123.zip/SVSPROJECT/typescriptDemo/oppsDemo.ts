export  module Investment {

    export class Currency{

        private currentname:string;
        private value:number;

        //contructor
        constructor(name:string,value:number){
            this.currentname=name;
            this.value=value;
        }
    }

    export class Trader {

        private traderId: number;
        private name: string;
        private tradeLimit: number;
        private country: string;

        constructor(id:number,name:string,limit:number,country:string) {

            this.traderId = id;
            this.name = name;
            this.tradeLimit = limit;
            this.country = country;
        }


        set tradeId(value: number) {
            this.traderId - value;
        }

        set setname(value: string) {
            this.name = value;
        }

        set setcountry(value: string) {
            this.country = value;
        }


        set settradeLimit(value: number) {
            this.tradeLimit = value;
        }


        get getTradeId(): number {
            return this.traderId
        }

        get getName(): string {
            return this.name
        }

        get getcountry(): string {
            return this.country;
        }

        get gettradeLimit(): number {
            return this.tradeLimit;
        }
    }

}

/*

var  t=new Trader();
console.log(t.getName);
console.log(t.setname);
console.log(t.setcountry);
*/


/*

var tradeObj=new Trader(1234,"kumar",2121,"india");

console.log("Trade ID-->");
console.log("Trade Name-->",tradeObj.getName);
console.log("Trade Limit-->",tradeObj.gettradeLimit);
console.log("Trade country-->",tradeObj.getcountry);
*/
