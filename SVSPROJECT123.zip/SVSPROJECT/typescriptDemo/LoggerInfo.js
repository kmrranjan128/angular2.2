"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var loggerDemo_1 = require("./loggerDemo");
var logger = new loggerDemo_1.FileLogger();
logger.writeToLog("Exception occurred");
