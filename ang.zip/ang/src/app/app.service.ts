import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class AppService {
    

	// url: string
    // constructor(private http : Http){
    //     this.url  = 'http://127.0.0.1:8000/book_filter'
    // }

    // search_word(){
    //     return this.http.get(this.url).map(res => {
    //     	return res.json().map(item => {
    //             console.log(item)
    //     		//return item.word
    //     	})
    //     })
    // }
}