import { Component } from '@angular/core';
import {FormControl,FormGroup} from '@angular/forms';
import {AppService} from './app.service'
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import {Http, Response} from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [AppService]
})
export class AppComponent {
	options: string[];
	book_search:string[];
	//myform: FormGroup;
	searchTerm :FormControl = new FormControl();
	myControl: FormControl = new FormControl();
	// username: FormControl = new FormControl();
  	// password: FormControl = new FormControl();

   constructor(private service: AppService,private http: Http){
		this.http.request('http://127.0.0.1:8000/book_filter').subscribe((res: Response) => {
		this.options= res.json().book_filter;
   });
}

getPosts(book_search){
	this.http.request('http://127.0.0.1:8000/book_search?book='+book_search+'').subscribe((res: Response) => {
		this.book_search= res.json().book_information;
		console.log(this.book_search)
   });
}

onClickSubmit(data) {
	//alert("Entered Email id : " + data.emailid);
	if(data.username == ""){
		alert("Please Enter the username");

	}else if(data.password == ""){
		alert("Please Enter the password");
	}else{
		console.log(data.username);
	}
 }



}
