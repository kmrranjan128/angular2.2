/*
var mongoose=require('mongoose');
var configRef=require('./dbConfig');

mongoose.Promise=global.Promise;
// method one
mongoose.connect('mongodb://localhost:27017/learningdb',{
    /!*mongoose.connect('mongodb://'+configRef.mongourl+':'+configRef.mongoport+'/'+configRef.mongodb+',{*!/
    useMongoClient:true,
    connectTimeoutMS:1000
});

// method two

/!*
 option={
    useMongoClient:true,
    connectTimeout:1000
}

mongoose.connect(configRef.mongourl,configRef.mongodb,configRef.mongoport,option)


*!/

var trainerSchema=new mongoose.Schema({
  name:String,
  email:{
      type:String,
      unique:true
  },
  mobileNo:{
      type:Number,
      validate:{
          validator:function (v) {
              /!*return /\d{3}-\d{4}/.test(v);*!/
              return /\d{10}/.test(v);
          },
          message:'{VALUE} is not a valid Phone Number !'
      }
  },
  skillSet:[String]

});


var traineeSchema=new mongoose.Schema({

    tranieeId:Number,
    traineeName:String,
    project:String,
    location:String,
    trainerRef:[{type:mongoose.Schema.Types.ObjectId,ref:'TrainerModel'}]


});

exports.TrainerModel=mongoose.model('TrainerModel','trainerSchema');
exports.TraineeModel=mongoose.model('TraineeModel','traineeSchema');





*/


var mongoose = require('mongoose');
var configRef = require('./dbconfig');

mongoose.promise = global.Promise;
//method1
mongoose.connect('mongodb://localhost:27017/learningdb', {
    useMongoClient:true,
    connectTimeoutMS:1000
})

//method2
/*options={
    useMongoClient: true,
    connectTimeoutMs: 1000
}
mongoose.connect(configRef.mongourl,configRef.mongodb,configRef.mongoport,options);
*/

//schema creation
var trainerSchema = new mongoose.Schema({
    name:String,
    email:{
        type:String,
        unique:true
    },
    mobileNo:{
        type:Number,
        validate: {
            validator: function (V) {
                return /\d{10}/.test(V);

            },
            message: '{VALUE} is not a valid mobile number!'
        }
    },
    skillaSet:[String]
})

var traineeSchema  = new mongoose.Schema({
    traineeId:Number,
    traineeName:String,
    project:String,
    location:String,
    trainerRef:[{type:mongoose.Schema.Types.ObjectId,ref:"TrainerModel"}]
})
exports.TrainerModel=mongoose.model('TrainerModel',trainerSchema);
exports.TraineeModel=mongoose.model('TraineeModel',traineeSchema);

console.log("model ready...");



