var mongoose=require('mongoose');
var trainnerModel=require('./learningShema').TrainerModel;

exports.getTranerData=function () {
    var db=mongoose.connection;
    db.once('open',function () {
        console.log("connection opened !")
    })
data=trainnerModel.find({}).exec(function (err,response) {
    return (response);
})
    return data;
}



exports.addTrainer=function (trainer) {
//console.log(trainer);
    var db=mongoose.connection;
    db.once('open',function () {
        console.log("connection opened !")
    })

    var obj=new trainnerModel({
        name:trainer.name,
        email:trainer.email,
        mobileNo:trainer.mobileNo,
        skillaSet:trainer.skillaSet
    })

    var data=obj.save(function(err,result){

        if(!err){
            console.log(result);
            return ({"message":"success"});
        }else{
            return ({"message":"Try Again"});
        }
    })

    return data;


}

/*exports.getTranerData().then(function (res) {
    console.log(res)
})*/
/*trainer={
    name:"Parameswaribala",
    email:"Parameswaribala@gmail.com",
    mobileNo:"9952032862",
    skillSet:["Node","Python"]

};
exports.addTrainer(trainer).then(function (res) {

});*/






