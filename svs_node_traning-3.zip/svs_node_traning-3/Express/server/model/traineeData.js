var mongoose=require('mongoose');
var trainnerModel=require('./learningShema').TrainerModel;
var traineeModel=require('./learningShema').TraineeModel;

exports.getTranerData=function () {
    var db=mongoose.connection;
    db.once('open',function () {
        console.log("connection opened !")
    })
    data=traineeModel.find({}).exec(function (err,response) {
        return (response);
    })
    return data;
}



exports.addTrainee=function (trainerName,trainee) {
    console.log(trainerName);
    console.log(trainee);
    var db=mongoose.connection;
    db.once('open',function () {
        console.log("connection opened !")
    })

    result=traineeModel.findOne({name:trainerName},function (err,res) {
        console.log(res);
        var obj=new traineeModel({
            traineeId:trainee.traineeId,
            traineeName:trainee.traineeName,
            project:trainee.project,
            location:trainee.location,
            trainerRef:res


        })
        console.log(obj)
        var data=obj.save(function(err,result){
            console.log("inside");
            if(!err){
               // res.send(result);
                return ({"message":"success"});
            }else{
                return ({"message":"Try Again..."});
            }
        })

    })


    var obj=new trainnerModel({
        name:trainer.name,
        email:trainer.email,
        mobileNo:trainer.mobileNo,
        skillaSet:trainer.skillaSet
    })



    var data=obj.save(function(err,result){

        if(!err){
            console.log(result);
            return ({"message":"success"});
        }else{
            return ({"message":"Try Again"});
        }
    })

    return data;


}

/*trainer={
    traineeId:1,
    traineeName:"laldev",
    project:"Node",
    location:"olive road",

}


exports.addTrainee("ravi",trainer).then(function (res) {
    console.log(res)
})*/

/*exports.getTranerData().then(function (res) {
    console.log(res)
})*/
/*trainer={
    name:"Parameswaribala",
    email:"Parameswaribala@gmail.com",
    mobileNo:"9952032862",
    skillSet:["Node","Python"]

};
exports.addTrainer(trainer).then(function (res) {

});*/






