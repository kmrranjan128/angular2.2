var expressRef=require('express');
var fnRef=require('../model/connectiontest');
var https=require('https');
var hrrp=require('http');
var fs=require('fs');
var bodyParse=require('body-parser');
var trainerDataRef=require('../model/trainnerData');
var traineerDataRef=require('../model/traineeData');

var app=new expressRef();



app.use(bodyParse.urlencoded({ extended: false }));
app.use(bodyParse.json());



app.get('/',function (req,res) {
    res.send("API path is up.....");
})

app.use('/images',expressRef.static('../../resources'))


// mongodb

app.post('/addTrainerData',function (req,res) {

    console.log(req.body)
    trainee={
        traineeId:req.body.traineeId,
        traineeName:req.body.traineeName,
        project:req.body.project,
        location:req.body.location,

    }
    trainee={
        trainee:req.body.trainer

        }

    traineerDataRef.addTrainee(req.body.trainee,trainee).then(function (res) {
        res.send("Trainee Data add...");
    })


})



app.get('/getTrainerData',function (req,res) {

    var multipleData=[];
    fnRef.getCustomerList().then(function (data) {
       // res.send(data);
        multipleData.push(data);
        trainerDataRef.getTranerData().then(function (tdata) {
            multipleData.push(tdata)
            res.send(multipleData);

        })
    }).catch(
        /*(err)=>setImmediate()=>{throw err}*/
    )


})


app.post('/addTrainerData',function (req,res) {

    //console.log(req.body);
    trainer={
        name:req.body.name,
        email:req.body.email,
        mobileNo:req.body.mobileNo,
        skillaSet:req.body.skillaSet

    };
    trainerDataRef.addTrainer(trainer).then(function (info) {
console.log(info);


        res.send('{"message":"success"}');
    })



})

// End mongodb








app.get('/getCustomer',function (req,res) {

    //select
    fnRef.getCustomerList().then(function(rows) {
        res.send(rows);
    }).catch()


})

//post

app.post('/addCustomer',function (req,res) {
    //var data=[req.body.id,req.body.name,req.body.dob];
   var data=[106,'Manish','1992/02/02'];
    console.log(data)
    fnRef.getAddCustomer(data).then(function(info) {
        //console.log(res)
        res.send(info);

    },function (error) {
        res.send("{invalid...}");
    }).catch()

//res.send("welcome to shriram value Service");

})



/*
var options = {
    key: fs.readFileSync('../ssl/key.pem'),
    cert:fs.readFileSync('../ssl/cert.pem'),
    passphrase: 'test'
};

var server = https.createServer(options, function (request, response) {
    fs.readFile('index.html', function (error, data) {
        response.writeHead(200, {'Content-Type': 'text/html'});
        response.end(data);
    });
}).listen(8080, function(){
    console.log('server running');
});*/



var port=8080;
app.listen(port,function () {
    console.log("server listening on port http://localhost:",+port);
});



//select
/*fnRef.getCustomerList().then(function(rows) {
    console.log(rows);
}).catch()*/


//insert
/*
fnRef.getAddCustomer().then(function(rows) {
    console.log(rows);
}).catch()
*/

//update
/*fnRef.getUpdateCustomer().then(function(rows) {
    console.log(rows);
}).catch()

//delete
fnRef.getDeleteCustomer().then(function(rows) {
    console.log(rows);
}).catch()*/

