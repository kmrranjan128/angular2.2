from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.decorators import api_view
from django.http import JsonResponse
from book.models import BookStore,Book
# Create your views here.

@api_view(['POST'])
def book_insert(request):
	if request.method == "POST":
		book_info = request.data
		print(book_info)
		book=Book(book_info["book_name"])
		book_store=BookStore(book_type=book_info["book_type"],book_author=book_info["book_author"],book_desc=book_info["book_desc"],book_name=book).save()
		print("book_store")

	#BookStore("1",'java','')

@api_view(['GET'])
def book_edit(request):
	pass

@api_view(['POST'])
def book_delete(request):
	pass

@api_view(['POST'])
def book_update(request):
	pass


def book_search(request):
	pass

def home(request):
	return render(request,'home/index.html',{})
