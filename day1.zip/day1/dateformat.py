# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 12:23:08 2018

@author: admin
"""

from datetime import date;

print(date.today().strftime("%d/%m/%Y"));

#multiple assigments
ipaddress=copyAdress='127.0.0.1';
print(copyAdress);
print(ipaddress);