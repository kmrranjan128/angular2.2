# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 12:41:17 2018

@author: admin
"""

import random;
randomvalue = random.randint(1,100);
if(randomvalue > 100):
    print("Number is above 100");
elif((randomvalue > 10) and (randomvalue < 100)):
    print("Number is in between 10 and 100");
else:
    print("Number is below 10")
    
    #range testing
print(110<randomvalue<=500);