# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 16:38:32 2018

@author: admin
"""

customerInfo={'customerId':12345,'customerName':'kumar',
          'dob':'05/08/1992'};
#only keys              
print(customerInfo.keys())

#only values
print(customerInfo.values())

for key in customerInfo.keys():
    if(key is 'dob'):
        print(customerInfo[key]);
        
        

customersList=[{"customerId":12345,'customerName':'ranjan','dob':'08/09/1993','phone':[123456754,45872154698],'ssid':(464654)},
                {"customerId":54875,'customerName':'manish','dob':'08/09/1992','phone':[1234563365],'ssid':(4646545454)},
                {"customerId":4545,'customerName':'manu','dob':'08/09/1994','phone':[123456754,65465464,6546549486],'ssid':(87879879)},
                {"customerId":664,'customerName':'rakesh','dob':'08/09/1997','phone':[123456754,654654541,32132131,86764113],'ssid':(9564641)}]  
print(customersList);
#print(customersList); 
for customer in customersList:
    print(customer.items());
    for key in customer.keys():
        if(key is 'ssid'):
            print("\n SSID",'--->',customer[key]);
            for phoneNo in customer['phone']:
                print(phoneNo,end='\t');

#items
for customer in customersList:
    for (key,value) in customer.items():
        print(key,'-->',value);                
                
    