# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 17:06:42 2018

@author: admin
"""

#1
def getData(data):
    list=[]
    for _ in data:
        list.append(_+5);
    print(list);
    return list;
    
getData([12345,23,23,12]); 

#2
def m1():
    print("welcome");

m1();    



#3
from datetime import date;

holydayList={
        '1/1/2018':'New Year',
        '14/1/2018':'Pongal',
        '26/1/2018':'Republic Day'
        }

def check(data):
    #print(data);
    status=False;
    for key in holydayList.keys():
        
        if(key is data):
            print(key)
            status=True;
            print(holydayList[key]);
        else:
            status=False;
            if(status is False):
                print("Working Day....");
            

check(date.today().strftime("%d/%m/%Y"));


    
        


    