# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 15:01:47 2018

@author: admin
"""

deviceList=['PC-1','127.0.0.1','VLAN',8000];

for _ in deviceList:
    if(type(_) is str):# int
        print(_);
 #output       
        '''
        str           int
        ----          -----
        PC-1           8000
        127.0.0.1
        VLAN
        '''

for _ in deviceList:
    if(type(_) != str) and (type(_) != bool):
        print(_);
        
        
        #dynamic List Generate
import random;
randomList=[];
for _ in range(1,5):
    randomList.append(random.randint(1,400));
    print(randomList);
    
    # sort and pring
    randomList.sort();
    print(randomList);
    
    #reverse and pring
    randomList.reverse();
    print(randomList);
    
    productIdList=[4,3,2,8];
    productList=["Tab","PC","Mobile","Printer"];
    #concat operttion
    print(productIdList+productList);
    
    #repetition
    print(productIdList*5);
    
    # zip function
    product=[];
    for (id,name) in zip(productIdList,productList):
        product.append(id);
        product.append(name);
    print(product);
    
    # join operation
    print("->".join(productList));
    #nested list
    
    deviceArray=[['PC-1', '127.0.0.1', 'Mobile1', 'Printer1'],
                 ['PC-2', '127.0.0.2', 'Mobile2', 'Printer2'],
                 ['PC-3', '127.0.0.3', 'Mobile3', 'Printer3'],
                 ['PC-4', '127.0.0.4', 'Mobile4', 'Printer4']];
  

# =============================================================================
for i in range(len(deviceArray)):
    for j in range(len(deviceArray[i])):
         print(deviceArray[i][j], end=' ') 
        # print()
# =============================================================================
    
# =============================================================================
for device in deviceArray:
 for elem in device:
     if(type(elem) is str):
         if(elem.find(".")>0):
             print(elem);
       
# =============================================================================

x = [i for i in range(10)]
print (x);
for _ in range(5):
    print(_);
  
    
    list1 = [3,4,5]
 
multiplied = [item*3 for item in list1] 
print(multiplied);
   



    
    
    
    