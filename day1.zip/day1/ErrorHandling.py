# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 12:52:42 2018

@author: admin
"""

data=input("Enter product rate ");
try:
    price=int(data);
    print(price);
except ValueError as e:
    print("Please enter the alphanumberic number");
#print(price)