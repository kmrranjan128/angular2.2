var http=require('http');
var urlRef=require('url');
var configRef=require('../ModulesDemo/dbConfig');
var queryString=require('querystring');
var server=http.createServer(function(req,resp) {
    resp.writeHead(200,{"Content-Type":"text/plain"})
    resp.end("Welcome to Shriram Value...");
    pathValue=urlRef.parse(req.url);
    console.log(pathValue.qu);


})
server.listen(configRef.port);
console.log("Server up Ready to rock http://localhost:"+configRef.port);