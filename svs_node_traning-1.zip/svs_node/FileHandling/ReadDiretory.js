var fs=require('fs');
console.log(process.cwd());

/*fs.readFile(process.cwd()+"\\svs.png",function (err,data) {

    if(err){
        console.log(err)
    }else{
        console.log(data.toString());
    }


})*/

console.log("Going to Read Diretory");

fs.readdir(".",function (failure,result) {

    if(failure)
        return console.error(failure);

    result.forEach(function (file) {

        console.log(file);
    });




});
