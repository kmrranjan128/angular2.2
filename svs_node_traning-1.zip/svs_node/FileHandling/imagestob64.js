var fs=require('fs');

function base64_encode(file) {
    var bitmap=fs.readFileSync(file);
    ///convert binary data to bASE64 encoded string
    return new Buffer(bitmap).toString('base64');
}

///function create to base 64 encoded string

function base64_decode(base64str,file) {

    var bitmap=new Buffer(base64str,'base64');
    fs.writeFileSync(file,bitmap);
    console.log("*** File create from base 64 encoded")


}

var base64str=base64_encode('svs.png');
console.log(base64str);
base64_decode(base64str,'svs2.jpg')



