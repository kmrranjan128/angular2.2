var fs=require('fs');
var zlib=require('zlib');
fs.createReadStream('data.txt')
    .pipe(zlib.createGzip())
    .pipe(fs.createWriteStream('data1.gz'));
console.log("File Compressed")