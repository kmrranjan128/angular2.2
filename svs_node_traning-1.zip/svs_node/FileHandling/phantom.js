var phantom=require('phantom');

phantom.create().then(function (ph) {
    ph.createPage().then(function (page) {
        page.open("https://www.npmjs.com/package/phantom").then(function (status) {
            page.render('samil1. pdf').then(function () {

                console.log("page render");
                ph.exit();

            });

        });

    });

});