var fs=require('fs');
var zlib=require('zlib');
fs.createReadStream('data.txt.gz')
    .pipe(zlib.createGunzip())
    .pipe(fs.createWriteStream('data2.txt'));
console.log("File Compressed")