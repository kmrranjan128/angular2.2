const fs=require('fs');
const server=require('http').createServer();
server.on('request',(req,res) => {
    fs.readFile('data1.txt', (err, data) => {
    if(err) {
        throw err;
    }
});
});
server.listen(8000);
console.log("server running");