var fs=require('fs');
const file=fs.createWriteStream('data1.txt');
for(var i=0;i<=1e6;i++){
    file.write('Shriram value Service');

}
file.end();

