var fs=require('fs');

var renderStream=fs.createReadStream('data.txt');

var writeStream=fs.createWriteStream('output.txt');

renderStream.pipe(writeStream);
console.log("Program Ended");
