var net=require('net');
var HOST='172.23.200.52';
//var HOST='127.0.0.1';
var PORT=3000;
var server=net.createServer(function (socket) {

    console.log("Connect :"+socket.remoteAddress+':'+socket.remotePort);
    socket.on('data',function (data) {
        console.log('DATA' +socket.remoteAddress+':'+data);
        socket.write('Messge From server-->you said"'+data+'"');
    });
    socket.on('close',function (data) {
        console.log('CLOSE' +socket.remoteAddress+':'+socket.remotePort);
    });


});
server.listen(PORT,HOST);
console.log('server listening on '+HOST+':'+PORT);