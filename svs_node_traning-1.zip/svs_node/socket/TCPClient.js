var net=require('net');
var HOST='172.23.200.52';
//var HOST='127.0.0.1';
var PORT=3000;

var client=new net.Socket();


client.connect(PORT,HOST,function () {

    console.log('CONNNECTED TO'+HOST+':'+PORT);
    client.write("I am Client");


});

client.on('close',function () {

    console.log("connnection close");
})


