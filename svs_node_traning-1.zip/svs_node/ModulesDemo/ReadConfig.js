var configRef=require('./dbConfig');

console.log(configRef.user);
