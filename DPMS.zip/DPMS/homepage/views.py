from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse

# Create your views here.


def index(request):
    template=loader.get_template('home.html')
    return HttpResponse(template.render())

def about(request):
    template = loader.get_template('about.html')
    return HttpResponse(template.render())

def programme(request):
    template = loader.get_template('programme.html')
    return HttpResponse(template.render())

def online_service(request):
    template = loader.get_template('online-service.html')
    return HttpResponse(template.render())

def gallery(request):
    template = loader.get_template('gallery.html')
    return HttpResponse(template.render())

def contact(request):
    template = loader.get_template('contactus.html')
    return HttpResponse(template.render())




