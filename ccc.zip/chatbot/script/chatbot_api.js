$("#otpval").keyup(function (event) {

    if (this.value === "") {

        $('#errorid').fadeOut('fast');
        $('#count').val("");
    }
    else {

    }

    if (event.keyCode == 13) {
        $("#confirmClick").click();
    }
});

$(function () {
    $("#ultabs li a").click(function () {
        $(".tab").hide();
        var myDiv = $(this).attr("href");
        $(myDiv).show();
        $('#ultabs a').removeClass("menuselect");
        $(this).addClass("menuselect");
    });
});

(function () {
    var dly = 200;
    $('.scroll-gal').each(function () { // caring about multi instances  
        var el = $(this),
            ul = $('ul', el);
        $('div', el).not('.vewport').click(function () {
            // in case any animation in progress we do nothing
            if (ul.is(':animated')) return;
            var first = $('li:first', ul),
                last = $('li:last', ul);
            switch ($(this).css('float')) { // relaying on css floats which might be not the case for complex galleries                  
                case 'left':
                    ul.css('left', -last.outerWidth(true)).prepend(last).animate({ 'left': 0 }, dly); break;
                case 'right':
                    ul.animate({ 'left': -first.outerWidth(true) }, dly, function () {
                        $(this).append(first).css('left', 0)
                    });
                    break;
            } // switch construction  
        }); // navigation click handler  
    }); // each loop  
})();






function chatbox() {
    $("#count").hide();
    $('.chat.is-visible').removeClass("is-visible");
    $('#fab_help').removeClass("is-visible");
    $('.prime').toggleClass('image_bot');
    $('.prime').toggleClass('is-active');
    $('.prime').toggleClass('zmdi-close');

}




function myFunction() {
    var x = document.getElementById("options");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
}



var otpValue;
var checkOtp;
var mobile_response;
var newUserMobileNo;
var newUserEmail;
var userType;
var userObj = {};
var existingUserObj = {};
var Phone;
var checkUser;
var error;
var inputType;
var tabIndex;
var setCallFlag=false;


function save(inputValue) {

    $.ajax
        ({
            type: "POST",
            url: "http://localhost:8080/findUsers",
            crossDomain: true,
            dataType: "json",
            data: inputValue,
        }).done(function (data) {


            if (data.messageresult.statuscode == '00001') {

                userType = 'newUser';


                if (mobile_response.includes('@') === true) {
                    document.getElementById("userEmail").value = mobile_response;
                }
                else {
                    document.getElementById('userMobile').value = mobile_response;

                }
                $('#3').show().siblings('div').hide();
            }
            if (data.messageresult.statuscode == '0000') {

                userType = 'oldUser';
                $('#4').show().siblings('div').hide();
            }
        })
}


function makeid() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < 5; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}

function validateUser() {
    if ($('#userName').val() != "" && $('#userMobile').val() != "" && $('#userEmail').val() != "") {
        userObj.userName = $('#userName').val();
        userObj.userEmail = $('#userEmail').val();
        userObj.userMobile = parseInt($('#userMobile').val());
        $('#ProceedClick').prop('disabled', false);
    } else {
        $('#ProceedClick').prop('disabled', true);
    }
}


$('#btnClick').on('click', function () {
     $('#otpval').val('');
     $('#confirmClick').prop('disabled', true);
    if ($('#1').css('display') != 'none') {
             $("#count").show();
             $("#showCount").show();
             $("#errorid").hide();  
    $('#2').show().siblings('div').hide();
        
    } else if ($('#2').css('display') != 'none') {
        $('#1').show().siblings('div').hide();
    }
    clockstart();
});
$('#btnClick1').on('click', function () {
    $('#otpval').val('');
    $('#confirmClick').prop('disabled', true);
console.log("countCheck",countCheck);
        
    if ($('#1').css('display') != 'none') {
         if(countCheck==="Email"){
           console.log("154_email");
             $("#count").hide();
             $("#showCount").hide();
             $("#errorid").hide();  

         }else{
            clockstart();
          
         }
        $('#2').show().siblings('div').hide();
    } else if ($('#2').css('display') != 'none') {
        $('#1').show().siblings('div').hide();
    }
    
})

$('#confirmClick').on('click', function () {

    checkOtp = $('#otpval').val();
    checkOtp = parseInt(checkOtp);

    if (userType === "newUser") {


    } else {

        var typeCheckValidate = mobile_response.includes("@");
        if (typeCheckValidate === true) {
            checkUser = { "email": mobile_response };

        } else {
            var checkMobile = parseInt(mobile_response);
            checkUser = { "mobileNo": checkMobile };

        }

    }


});


$('.todivfive').on('click', function () {
    if ($('#4').css('display') != 'none') {
        $('#5').show().siblings('div').hide();
    } else if ($('#5').css('display') != 'none') {
        $('#4').show().siblings('div').hide();
    }
});

$('.closeotp').on('click', function () {
    if ($('#5').css('display') != 'none') {
        $('#4').show().siblings('div').hide();
    } else if ($('#5').css('display') != 'none') {
        $('#4').show().siblings('div').hide();
    }
});


$('.closeotp').on('click', function () {

    if ($('#1').css('display') != 'none') {
        $('#2').show().siblings('div').hide();
    } else if ($('#2').css('display') != 'none') {
        $('#1').show().siblings('div').hide();
    }
    clockstop();

    var typeCheck = mobile_response.includes("@");
    if (typeCheck === true) {
        $("#tab-2").hide();
        $("#tab-1").show();
        $('#btnClick').prop('disabled', true);
    } else {
        $("#tab-1").hide();
        $("#tab-2").show();
        $('#btnClick1').prop('disabled', true);
    }


});



// To ensure only valid mobile numbers(7000000000 to 9999999999) are entered
$('body').on('keypress', '.js-input-mobile', function () {
    var $input = $(this),
        value = $input.val(),
        length = value.length,
        inputCharacter = parseInt(value.slice(-1));
        // console.log("inputCharacter",inputCharacter);
         console.log("value",value);
        // console.log("length",length);

        // if(inputCharacter >=6){
        //     $('#btnClick1').prop('disabled', true);
        //   console.log("266",inputCharacter);
        // }else{
        //      console.log("268",inputCharacter);
        //    value=""; 
        //    $input.val('')
        // }


    if (!((length > 1 && inputCharacter >= 0 && inputCharacter <= 9) || (length === 1 && inputCharacter >= 6 && inputCharacter <= 9))) {
        $input.val(value.substring(0, length - 1));
        console.log("277",$('#email').val('')[0]);
         // $('#email').val('');
    }else{
        console.log("279",$input.val());
    }

});

$('body').on('keypress', '.js-input-email', function () {
    //var re = /([A-Z0-9a-z_-][^@])+?@[^$#<>?]+?\.[\w]{2,4}/.test(this.value);
    var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(this.value);
    if (!re) {
        $('#btnClick1').prop('disabled', true);
    } else {
        $('#btnClick1').prop('disabled', false);
    }
});

function isValidEmailAddress(emailAddress) {
    debugger;

};


//allow integers only to the OTP textbox

// $(document).ready(function () {
//   //called when key is pressed in textbox
//   $("#otpval").keypress(function (e) {
//      //if the letter is not digit then display error and don't type anything
//      if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
//         //display error message
        
//                return false;
//     }
//    });
// });




//TO make button enable based on maxlength////////
var tab_id;
$(function () {

    $('ul.tabs').delegate('li:not(.current)', 'click', function () {
        $(this).addClass('current').siblings().removeClass('current')
            .parents('div.section').find('div.box').eq($(this).index()).fadeIn(150).siblings('div.box').hide();
    })


    $('ul.tabs li').click(function () {
        tab_id = $(this).attr('data-tab');
        document.getElementById('currentTab').innerHTML = tab_id;
        if (tab_id === "Mobile No.") {
            $("#tab-1").hide();
            $("#tab-2").show();
        } else {
            $("#tab-2").hide();
            $("#tab-1").show();
        }


    })

})





/////////////// TABS FOR EMAIL AND SMS ////////////////////////////////////

$('#chatSend').keyup(function () {

    // If value is not empty
    if ($(this).val().length == 0) {
        // Hide the element
        $('#fab_attach').show();
        $('#fab_send').hide();
    } else {
        // Otherwise show it
        $('#fab_attach').hide();
        $('#fab_send').show();
    }
}).keyup(); // Trigger the keyup event, thus running the handler on page load




/////////////// above code is to Show/hide send and attach ////////////////////////////////////



function doCheck() {
    var allFilled = true;
    $('#email').each(function () {
        mobile_response = $('#email').val();
        document.getElementById('mobile').innerHTML = mobile_response;
        if ($(this).val().length != 10) {
            allFilled = false;
            return false;
        }
    });
    $('#btnClick').prop('disabled', !allFilled);
}

function doUserMobileCheck() {
    $('#userMobile').each(function () {
        if ($(this).val().length != 10) {
            $('#ProceedClick').prop('disabled', true);
        } else {
            validateUser();
        }
    });

}



/// Email Response


function doEmailCheck() {
    var allFilled = true;
    $('#email_req').each(function () {
        mobile_response = $('#email_req').val();
        document.getElementById('mobile').innerHTML = mobile_response;
        // var re = /([A-Z0-9a-z_-][^@])+?@[^$#<>?]+?\.[\w]{2,4}/.test(this.value);
        var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(this.value);
        if (!re) {
            $('#btnClick1').prop('disabled', true);
        }
        else {
            $('#btnClick1').prop('disabled', false);
        }
    });


}


function doUserEmailCheck() {
    var allFilled = true;
    $('#userEmail').each(function () {
        mobile_response = $('#userEmail').val();

        var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(this.value);
        if (!re) {

            $('#ProceedClick').prop('disabled', true);
        }
        else {
            validateUser();
        }
    });

}


function doUserNameCheck() {

    $('#userName').each(function () {
        if ($(this).val().length <= 2) {
            $('#ProceedClick').prop('disabled', true);
        } else {
            validateUser();
        }

    });

};


$(document).ready(function () {
    $('#email').keyup(doCheck).focusout(doCheck);
    $('#email_req').keyup(doEmailCheck).focusout(doEmailCheck);
    $('#userEmail').keyup(doUserEmailCheck).focusout(doUserEmailCheck);
    $('#userMobile').keyup(doUserMobileCheck).focusout(doUserMobileCheck);
    $('#userName').keyup(doUserNameCheck).focusout(doUserNameCheck);
    $('#otpval').keyup(otpCheck).focusout(otpCheck);
    $("#tab-2").hide();
    $("#tab-1").show();
    $("#count").show();
    $("#showCount").show();
    document.getElementById('currentTab').innerHTML = "Email Id";
   $("#otpval").keypress(function (e) {
      //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
//         //display error message
        
                return false;
         }
     });


});






function otpCheck() {
    var Filled = true;

    $('#otpval').each(function () {
        if ($(this).val().length != 6) {
            if($(this).val().length==0){
            console.log("439_length_0",counter);
            }else{
               setCallFlag=true;
               console.log("441_length is greater than 1",$(this).val().length);
               $("#count").hide();
              // $("#showCount").hide(); 
                //$("#errorid").hide(); 

            }
             Filled = false;
             return false;
        }else{
            console.log("451_6digit",$(this).val().length);
             $("#count").hide();
             $("#showCount").hide(); 
             $("#errorid").hide(); 

        }
    });
    $('#confirmClick').prop('disabled', !Filled);
}


var myfunc;
var testValue;
var counter;
function clockstart() {
    $("#showCount").show();
    // $("#errorid").hide();
    var hidetimer=document.getElementById("tabIndex");
    var test=$('#mobile').val();
    //var test1=$('#mobile').val()
    testValue = document.getElementById('mobile').value;
    counter = 59;
    myfunc = setInterval(function () {

      

        counter--;
        if (counter >= 0) {
           
             //$("#errorid").hide();
            span = document.getElementById("count");
            span.innerHTML = counter;
        }
        otpInputVal=$('#otpval').val();
         console.log("486-CounterVal",counter);
        if (counter === 0 && otpInputVal.length==0 ) {
            console.log("flag",setCallFlag,mobile_response);
            if(setCallFlag==false){
                console.log("error & empty value of otp and the counter",$('#otpval').val(),counter);
               console.log("Calling you");
             error = "Will receive your otp throw phone  ...";
             $("#errorid").show();
             $("#count").hide();
             $("#showCount").show();
             document.getElementById("errorid").innerHTML = error;
             var x = document.getElementById("count");
             x.style.display = 'none';
             sendPhoneCallOTP(mobile_response);
           }else{
            console.log("503 Counter greater than zero ");
           }
        }
    }, 1000);
};

function clockstop() {
      //$("#errorid").hide();
    span = document.getElementById("count");
    span.innerHTML = 59;
    clearInterval(myfunc);
}




//toggleFab();
//define chat color
if (typeof (Storage) !== "undefined") {
    if (localStorage.getItem('fab-color') === null) {
        localStorage.setItem("fab-color", "amber");
    }
    $('.fabs').addClass(localStorage.getItem("fab-color"));
    localStorage.setItem("mute", "1");
    sessionStorage.setItem("mic", "1")
    $('#un_mute_button').hide();
} else {
    $('.fabs').addClass("amber");
}

//Fab click
$('#prime').click(function () {
    toggleFab();
});
var voices = [];
var voiceindex; var clicks = 0;
//Populate voice for admin msg
function populateVoiceList() {

    if (typeof speechSynthesis === 'undefined') {
        return;
    }

    voices = window.speechSynthesis.getVoices();


    for (var i = 0; i <= voices.length - 1; i++) {
        if (voices[i].name.includes("Zira")) {
            voiceindex = i;
        }
    }

}



populateVoiceList();

if (typeof speechSynthesis !== 'undefined' && speechSynthesis.onvoiceschanged !== undefined) {
    speechSynthesis.onvoiceschanged = populateVoiceList;
}

//Speak admin msg
function botSpeak(text) {
    if ('speechSynthesis' in window) {
        var msg = new SpeechSynthesisUtterance(text);
        msg.voice = voices[voiceindex];
        msg.volume = localStorage.getItem("mute");
        window.speechSynthesis.speak(msg);
    }
}

//Toggle chat and links
function toggleFab() {
    $('.prime').toggleClass('image_bot');
    $('.prime').toggleClass('zmdi-close');
    $('.prime').toggleClass('is-active');
    $('#prime').toggleClass('is-float');
    $('.chat').toggleClass('is-visible');
    $('.fab').toggleClass('is-visible');
}

//User msg
function userSend(text) {
    var img = '<i class="zmdi zmdi-account"></i>';
    $('#chat_converse').append('<div class="chat_msg_item chat_msg_item_user"><div class="chat_avatar">' + img + '</div>' + text + '</div>');
    $('#chatSend').val('');
    if ($('.chat_converse').height() >= 256) {
        $('.chat_converse').addClass('is-max');
    }
    $('.chat_converse').scrollTop($('.chat_converse')[0].scrollHeight);
}

//Admin msg
function adminSend(text) {
    $('#chat_converse').append('<div class="chat_msg_item chat_msg_item_admin"><div class="chat_avatar"><i class="zmdi zmdi-headset-mic"></i></div>' + text + '</div>');
    botSpeak(text);
    if ($('.chat_converse').height() >= 256) {
        $('.chat_converse').addClass('is-max');
    }
    $('.chat_converse').scrollTop($('.chat_converse')[0].scrollHeight);

    Record();
}

//Function To Create Controls 
function CreateControls(text) {
    $('#chat_converse').append('<div class="chat_msg_item chat_msg_item_admin"><div class="chat_avatar"><i class="zmdi zmdi-headset-mic"></i></div>' + text + '</div>');
    botSpeak(text);
    if ($('.chat_converse').height() >= 256) {
        $('.chat_converse').addClass('is-max');
    }
    $('.chat_converse').scrollTop($('.chat_converse')[0].scrollHeight);
}

//Send input using enter and send key
$('#chatSend').bind("enterChat", function (e) {

    var accessToken = $("#txt_name").val();

    var baseUrl = "https://api.api.ai/v1/";
    var msg = $("#chatSend").val();
    if (sessionStorage.getItem("action") != "null" && sessionStorage.getItem("action") != null) {
        myService(msg);
    }
    else {
        $.ajax({

            type: "POST",
            url: baseUrl + "query?v=20150910",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            headers: {
                "Authorization": "Bearer " + accessToken
            },
            data: JSON.stringify({ query: msg, lang: "en", sessionId: "somerandomthing" }),

            success: function (data) {
                chatResp(data);
                var msg1 = data.result.fulfillment.messages
                var title = '', subtitle = '', card = '', reply = ''
                for (var i = 0; i <= msg1.length - 1; i++) {
                    // Condtion to handle text Response --Begin
                    if (msg1[i]["type"] == 0 && msg1[i].speech != '') {

                        if (data.result.action == "event") {
                            getState(msg1[i].speech);
                        }
                        else {

                            adminSend(msg1[i].speech);
                        }
                    }
                    // Condtion to handle text Response --End


                    // Condtion to handle Buttons and Cards Response --Begin
                    else if (msg1[i]["type"] == 1) {

                        if (msg1[i].title != '') {
                            title = msg1[i].title;
                        }
                        if (msg1[i].subtitle != '' && msg1[i].subtitle != null) {
                            subtitle = msg1[i].subtitle;
                        }
                        if (msg1[i].imageUrl != '' && msg1[i].imageUrl != null) {
                            card = "<img src='" + msg1[i].imageUrl + "'/><div class='card-title'>" + title + "</div><div class='card-subtitle'>" + subtitle + "</div>";
                        }

                        for (var k = 0; k <= msg1[i].buttons.length - 1; k++) {
                            if (msg1[i]["type"] == 1 && msg1[i].imageUrl == null) {
                                card = card + "<button type='button' id='btn' class='btn btn-default btn-responsive btn-card ' target='_blank' onclick=Clickfunction('" + msg1[i].buttons[k].postback + "') style='margin:5px;'>" + msg1[i].buttons[k].text + "</button>";
                            }
                            if (msg1[i]["type"] == 1 && msg1[i].imageUrl != null) {
                                card = card + "<button type='button' id='btn' class='btn btn-default btn-responsive btn-card' target='_blank' onclick=Clickfunction('" + msg1[i].buttons[k].postback + "') style='width:100%'>" + msg1[i].buttons[k].text + "</button>";
                            }
                        }
                        CreateControls(card);
                    }
                    // Condtion to handle Buttons and Cards Response --End

                    // Condtion to handle Quick Replies  --Start
                    else if (msg1[i]["type"] == 2) {

                        reply = '<div>' + msg1[i].title + '</div>'
                        for (var rep = 0; rep <= msg1[i].replies.length - 1; rep++) {
                            reply = reply + "<button type='button' id='btn' class='btn btn-reply' target='_blank' onclick=ResponsiveButtons('" + msg1[i].replies[rep] + "')>" + msg1[i].replies[rep] + "</button>";
                        }
                        CreateControls(reply);
                    }
                    // Condtion to handle Quick Replies  --End


                    // Condtion to handle Images  --Start
                    else if (msg1[i]["type"] == 3) {

                        img = "<img src='" + msg1[i].imageUrl + "'/>";
                        CreateControls(img);
                    }
                    // Condtion to handle Images  --End


                    // condition to handle custom Payloads --Start
                    else if (msg1[i]["type"] == 4) {
                        var res = msg1[i].payload.publish;
                        var img = '';
                        for (var j = 0; j <= res.length - 1; j++) {

                            if (res[j].type == 0) { //Condition For Custom Text
                                for (var k = 0; k <= res[j].txt.length - 1; k++) {
                                    adminSend(res[j].txt[k].speech)
                                }
                            } else if (res[j].type == 1) { //Condition For Custom Button
                                for (var k = 0; k <= res[j].btn.length - 1; k++) {
                                    img = img + "<button type='button' id='btn' class='btn btn-default' target='_blank' onclick=Clickfunction('" + res[j].btn[k].postback + "') style='margin:5px;'>" + res[j].btn[k].text + "</button>";
                                }
                                CreateControls(img);
                            } else if (res[j].type == 2) { //Condition For Custom reply

                                var reply = "<div>" + res[j].title + "</div>";
                                for (var k = 0; k <= res[j].replies.length - 1; k++) {
                                    reply = reply + "<button type='button' id='btn' class='btn btn-reply' target='_blank' onclick=ResponsiveButtons('" + res[j].replies[k] + "')>" + res[j].replies[k] + "</button>";
                                }
                                CreateControls(reply)
                            }
                            else if (res[j].type == 3) { //Condition For Custom Image                                        

                                for (var k = 0; k <= res[j].images.length - 1; k++) {
                                    img = "<img src='" + res[j].images[k].imageUrl + "'class='card-img'/>";

                                }
                                CreateControls(img)

                            } else if (res[j].type == 5) { //Condition For Custom Card

                                var card = "<img src='" + res[j].imageUrl + "'/><div class='card-title'>" + res[j].title + "</div><div class='card-subtitle'>" + res[j].subtitle + "</div>"
                                for (var k = 0; k <= res[j].buttons.length - 1; k++) {

                                    card = card + "<button type='button' id='btn' class='btn btn-default btn-responsive btn-card' target='_blank' onclick=Clickfunction('" + res[j].buttons[k].postback + "') style='width:100%'>" + res[j].buttons[k].text + "</button>";

                                }
                                CreateControls(card)
                            }
                        }
                    }// condition to handle custom Payloads --End


                } // condition to handle Json Response --End

                //Condition to handle track action
                if (data.result.action == "track") {
                    sessionStorage.setItem("action", data.result.action);
                }


            },
            error: function () {
                //setResponse("Internal Server Error");
            }
        });//
    }
    userSend($('#chatSend').val());


});


//Creating Dynamic Buttons 
function appendspan() {
    var dynamicbuttons = '';
    for (var ap = 0; ap <= 6; ap++) {
        dynamicbuttons = dynamicbuttons + '<button >button' + ap + '</button>'
    }
    $("#dbuttons").append(dynamicbuttons);
}


//Redirection Buttons event
function Clickfunction(text) {
    window.open(text);
}

//
function ResponsiveButtons(Inputvalues) {

    $('#chatSend').val(Inputvalues);
    $("#chatSend").trigger("enterChat");
}

function myService(message) {

}

$('#fab_send').bind("enterChat", function (e) {
    /*userSend($('#chatSend').val());*/
    $("#chatSend").trigger("enterChat");
});
$('#chatSend').keypress(function (event) {
    if (event.keyCode === 13) {
        event.preventDefault();
        if (jQuery.trim($('#chatSend').val()) !== '') {
            $(this).trigger("enterChat");
        }
    }
});

$('#fab_send').click(function (e) {
    if (jQuery.trim($('#chatSend').val()) !== '') {
        $(this).trigger("enterChat");
    }
});

//Listen user voice
$('.fab_listen').click(function () {
    var recognition = new webkitSpeechRecognition();
    if (sessionStorage.getItem("mic") == 1) {
        recognition.onresult = function (event) {

            $('#chatSend').val(event.results[0][0].transcript);
            $("#chatSend").trigger("enterChat");
        }
        sessionStorage.setItem("mic", "1")
        recognition.start();
        recognition.onstart = function () {
            document.getElementById("cb-1").checked = true;
        }
        recognition.onend = function () {
            document.getElementById("cb-1").checked = false;
        }

    }
});

function Record() {
    var recognition = new webkitSpeechRecognition();


    recognition.onresult = function (event) {

        $('#chatSend').val(event.results[0][0].transcript);
        $("#chatSend").trigger("enterChat");
    }

    recognition.onend = function () {
        document.getElementById("cb-1").checked = false;
    }
    recognition.onaudioend = function () {
        recognition.start();
    }
    recognition.onspeechend = function () {
        recognition.start();
    }

    recognition.onstart = function () {
        document.getElementById("cb-1").checked = true;
    }

}


//Mute and Unmute
$('#mute_button').bind('click', function () {

    localStorage.setItem("mute", "0")
    $('#mute_button').hide();
    $('#un_mute_button').show();
});

$('#un_mute_button').bind('click', function () {

    localStorage.setItem("mute", "1")
    $('#mute_button').show();
    $('#un_mute_button').hide();
});


// Help
$('#fab_help').click(function () {
    userSend('Help!');
});

// Color options
$(".chat_color").click(function (e) {
    $('.fabs').removeClass(localStorage.getItem("fab-color"));
    $('.fabs').addClass($(this).attr('color'));
    localStorage.setItem("fab-color", $(this).attr('color'));
});

// Ripple effect
var target, ink, d, x, y;
$(".fab").click(function (e) {
    target = $(this);
    //create .ink element if it doesn't exist
    if (target.find(".ink").length == 0)
        target.prepend("<span class='ink'></span>");

    ink = target.find(".ink");
    //incase of quick double clicks stop the previous animation
    ink.removeClass("animate");

    //set size of .ink
    if (!ink.height() && !ink.width()) {
        //use parent's width or height whichever is larger for the diameter to make a circle which can cover the entire element.
        d = Math.max(target.outerWidth(), target.outerHeight());
        ink.css({
            height: d,
            width: d
        });
    }

    //get click coordinates
    //logic = click coordinates relative to page - parent's position relative to page - half of self height/width to make it controllable from the center;
    x = e.pageX - target.offset().left - ink.width() / 2;
    y = e.pageY - target.offset().top - ink.height() / 2;

    //set the position and add class .animate
    ink.css({
        top: y + 'px',
        left: x + 'px'
    }).addClass("animate");
})


var countCheck;

function otpGenerate(inputId) {
    $('#otpval').val('');
    $("#errorid").show(); 
    setCallFlag=false
    if (inputId === "email_req") {
        document.getElementById('tabIndex').innerHTML = "Email";
    } else {
        document.getElementById('tabIndex').innerHTML = "Mobile No.";
    }
    var inputValue = document.getElementById(inputId).value;
    var typeCheckInput = inputValue.includes("@");
   
    if (typeCheckInput === true) {
        countCheck="Email";
        inputType = "e";
      
    } else {
        countCheck="Mobile No.";
        inputType = "m";
        
    }


    $.ajax
        ({
            type: "POST",
            url: "http://localhost:8080/otpgenerate",
            crossDomain: true,
            dataType: "json",
            data: { 'inputValue': inputValue }
        }).done(function (response) {

        })
}


function verifyOTP() {


    if (inputType === "e") {
        document.getElementById("userEmail").value = mobile_response;
    }
    else {
        document.getElementById('userMobile').value = mobile_response;

    }
    var inputValue = mobile_response;
    var otp = document.getElementById('otpval').value;
    $.ajax
        ({
            type: "POST",
            url: "http://localhost:8080/otpVerification",
            crossDomain: true,
            dataType: "json",
            data: { 'inputValue': inputValue, 'OTP': otp, 'inputType': inputType }
        }).done(function (data) {
            // existing user
           // OTP varification session id generate
            localStorage.setItem('session', data.session);
            if (data.messageresult && data.messageresult.statuscode === "00000") {
                $('#4').show().siblings('div').hide();
            }

            else if (data.messageresult && data.messageresult.statuscode === "00001") {
               
            if($("#userEmail").val()==0){
                 console.log("yes");
                 $("#userMobile").attr("readonly", true); 
                 $('#userEmail').attr('readonly', false);
              }
            else{ 

                 console.log("no");
                 $("#userEmail").attr("readonly", true);
                 $("#userMobile").attr("readonly", false); 
                } 

                $('#3').show().siblings('div').hide();
            }
            else {
                error = data.messageresult.statusdescription;
                document.getElementById("errorid").innerHTML = error;
                var x = document.getElementById("errorid")
                x.style.display = "block";
            }

        })
}

// add new user

function addNewUser() {
    var userName = document.getElementById('userName').value;
    var userEmail = document.getElementById('userEmail').value;
    var userMobile = document.getElementById('userMobile').value;

    $.ajax
        ({
            type: "POST",
            url: "http://localhost:8080/addNewUser",
            crossDomain: true,
            dataType: "json",
            data: { name: userName, email: userEmail, mobileNo: userMobile }
        }).done(function (data) {
            console.log(data.session)
            localStorage.setItem('session', data.session)
            if (data.statuscode == "0000") {
                $('#4').show().siblings('div').hide();

            } else {
                error = data.statusdescription;
                document.getElementById("newUserError").innerHTML = error;
                var errorDiv = document.getElementById("newUserError")
                errorDiv.style.display = "block";
            }

        })
}

function sendPhoneCallOTP(inputValue){
    // var inputValue = mobile_response;
    $.ajax
    ({
        type: "POST",
        url: "http://localhost:8080/otpPhoneCallVerification",
        crossDomain: true,
        dataType: "json",
        data: { 'inputValue':inputValue }
    }).done(function (data) {

    })
}


function chatResp(text) {
    console.log(text)
    console.log(text.result.metadata.intentName)
    $.ajax({
        url: 'http://localhost:8080/chatbotresp',//ai.shriram
        dataType: "json",
        data: {id: text.id, intent: text.result.metadata.intentName, timeStamp: text.timestamp, resolvedQuery: text.result.resolvedQuery, messages: JSON.stringify(text.result.fulfillment.messages), session: localStorage.getItem('session')},
        type: 'POST',
        jsonpCallback: 'callback',
        success: function (data) {
           // var ret = jQuery.parseJSON(data);
           // $('#lblResponse').html(ret.msg);
            //console.log('Success: ')
        },
        error: function (xhr, status, error) {
            
           // $('#lblResponse').html('Error connecting to the server.');
        },
    });
        
}

