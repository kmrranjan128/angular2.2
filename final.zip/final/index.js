var express = require('express');
var bodyParser = require('body-parser');

 var otpControllerRef = require('./server/controller/OTP.controller');
var reg_data = require('./server/controller/registration.controller');
var appConfigRef = require('./config/appConfig');
var botSessionContr = require('./server/controller/botSession.controller');
var otpRouter = require('./server/routes/OTP.router');
var regRouter=require('./server/routes/registration.router');
var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});
// Router
app.use('/', otpRouter,regRouter);

var port = 8080;
app.listen(port, function () {
  appConfigRef.myConsoleLog("Server is listening in " + port + " port");
})
