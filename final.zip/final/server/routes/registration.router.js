var express = require('express');

var regController=require('../controller/registration.controller');
var botsession=require('../controller/botSession.controller');

var router = express.Router();

router.post('/addNewUser',regController.addRegistration);

router.post('/chatbotresp',botsession.addChatbot);

module.exports = router;