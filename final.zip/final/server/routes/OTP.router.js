var express = require('express');

var otpControllerRef=require('../controller/OTP.controller');
//var regController=require('../controller/registration.controller');
//var botSessionContr=require('../controller/botSession.controller');

var router = express.Router();

// OTP Number Generate
router.post('/OTPGenerate', otpControllerRef.GenerateOTPForLogin);

router.post('/otpVerification', otpControllerRef.otpVerification);
router.post('/otpPhoneCallVerification',otpControllerRef.sendOTPPhoneCall);

// check weather the user existing or not
//router.post('/findUsers',regController.findUser);

// Add New user register
/* router.post('/addNewUser',regController.addRegistration);


//router.post('/addBotSession',botSessionContr.addBotSession);

router.post('/addChatbotResp',botSessionContr.addChatbot); */

module.exports = router;