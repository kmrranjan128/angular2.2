var mongoose = require('mongoose');
datetime = require('node-datetime');
_ = require('lodash');

var saveSession = require('../models/botSession.model').botSession;
var saveChatbotResp = require('../models/botSession.model').ChatBot;
var session = require('./botSession.controller')

exports.sessionGen = function () {
    text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < 15; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
}

exports.addBotSession = function (data, session) {

    botsession = {
        name: data[0].name,
        email: data[0].email,
        mobileNo: data[0].mobileNo,
        session: session,
        date: datetime.create().format('m/d/Y'),
        time: datetime.create().format('H:M:S')
    }
    console.log(botsession);



    saveSession.create(botsession, function (err, result) {
        console.log("||||||||||||||||");
        console.log(result);


        /// (!err) ? res.send('{"statuscode":"0000","statusdescription":"successfully"}') : res.send('{"statuscode":"0001","statusdescription":"Duplicate email | mobile"}');
        // res.send('{"session":"'+result.session+'"}');
    });
}


// add chatbot Response
exports.addChatbot = function (req, res) {
    // console.log("id",JSON.parse(req.body[0]));

    chatBotRequest = {
        api_id: req.body.id,
        //Date_Time: req.body.timeStamp,
        intent: req.body.intent,
        user: req.body.resolvedQuery,
        bot: _.map(JSON.parse(req.body.messages), 'speech'),
        date: datetime.create().format('m/d/Y'),
        time: datetime.create().format('H:M:S'),
        botSessionRef: req.body.session

    }
    console.log("***********")
    console.log(chatBotRequest)
    saveChatbotResp.create(chatBotRequest, function (err, result) {
        (!err) ? res.send('{"statuscode":"0000","statusdescription":"successfully"}') : res.send('{"statuscode":"0001","statusdescription":"Duplicate email | mobile"}');

    });



}