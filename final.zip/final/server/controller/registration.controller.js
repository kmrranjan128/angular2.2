var mongoose = require('mongoose');

var registration = require('../models/registration.model').Registration;
var chatbot = require('../models/registration.model').ChatBot;
var botsessionRef=require('../controller/botSession.controller');

exports.addRegistration = function (req, res) {
    saveNewUser = {
        name: req.body.name,
        email: req.body.email,
        mobileNo: req.body.mobileNo,
    }
       var registeredMobile=false;
       var registeredEmail=false;  
        registration.find({mobileNo:req.body.mobileNo},function(err,result){
                if(result && result.length>=1){   
                 registeredMobile=true;
                 
                 //registeredEmail=false;
                }
                /* else {
                    registeredMobile=true;
                    registeredEmail=false;
                  } */
                registration.find({email:req.body.email},function(err,result){
                    if(result && result.length>=1){
                        registeredEmail=true;
                    }/* else{
                        registeredEmail=true;
                    } */
                    if(registeredMobile === true && registeredEmail === true){
                         res.send('{"statuscode":"0001","statusdescription":"Your Email & Mobile is already registered"}')
                         }
                     else if(registeredMobile === true && registeredEmail === false ){
                          res.send('{"statuscode":"0001","statusdescription":"Your Mobile Number is already registered"}');
                       }
                       else if(registeredEmail === true && registeredMobile === false ){
                        res.send('{"statuscode":"0001","statusdescription":"Your Email is already registered"}');
                       }
                    else{
                        registration.create(saveNewUser, function (err, result) {
                            var session=botsessionRef.sessionGen();
                            (!err) ? res.send({"statuscode":"0000","statusdescription":"successfully","session":session})+botsessionRef.addBotSession([result],session) : res.send('{"statuscode":"0001","statusdescription":"'+err+'"}');
                        });
                      }
                })
                 

        })
   
   
   
    
    


    
   
   


    /* registration.create(obj, function (err, result) {
        (!err) ? res.send('{"statuscode":"0000","statusdescription":"successfully"}') : res.send('{"statuscode":"0001","statusdescription":"Duplicate email | mobile"}');

    }); */
}