
var randomNum = require('random-number');
var datetime = require('node-datetime');
var http=require('http');

var configRef = require('../../config/dbConfig');
var appConfigRef = require('../../config/appConfig')
var mailConfigRef = require('../../config/mailConfig');
var OTPModel = require('../models/OTP.model').OTPModel;
var registration = require('../models/registration.model').Registration;
var botSession = require('../models/botSession.model').botSession;
var session=require('./botSession.controller');

var randomNumber;
var insertData;

// OTP has to be generated for new user registration based on their input(email/ mobile number), and returns the OTP to their respective email/mobile number
exports.GenerateOTPForLogin = function(req, res)
  {
   // console.log(req.body)
   // console.log(new Date());
   appConfigRef.myConsoleLog(!isNaN(req.body.inputValue));
    generateRandomNumber();
    
    if(!isNaN(req.body.inputValue))
     {
      insertDataToOTPModel=

       {
        inputType: "m",
        inputValue: req.body.inputValue,
        OTP: randomNumber,
        createdDate: new Date()
        }
       sendSMSOTP();
    }
    if(isNaN(req.body.inputValue))
    {
     insertDataToOTPModel=
      {
        inputType: "e",
        inputValue: req.body.inputValue,
        OTP: randomNumber,
        createdDate: new Date()
      }
       sendEmailOTP();
    }

//insert Mobile number or email id,OTP,Date and Time into database collection//

     OTPModel.create(insertDataToOTPModel, function(err, result)
      {
        if(!err) {
          res.json({"messageresult": {
          "statuscode": "0000",
          "statusdescription": "OTP sent successfully"
          }, 
          "otp": insertDataToOTPModel.OTP
          });
        }
        else 
        res.json({"messageresult": {
          "statuscode": "0001",
          "statusdescription": "OTP sent failed"
          }
          });
      })
    }

 //Generate 6 digit OTP from random Number for Login. That random number will generate between 100000 to 999999.
  generateRandomNumber = function()
   {
	   var options = 
	    {
  		  min:  100000,
   		  max:  999999, 
   		  integer: true
      }
     randomNumber = randomNum(options);
   }

// OTP sent to respective email for Login the chatbot
sendEmailOTP = function()
  {
    let mailOptions = {
      from: mailConfigRef.fromMailId, // sender address
      to: insertDataToOTPModel.inputValue, // list of receivers
      subject: 'SVS chatbot OTP', // Subject line
      text: `${insertDataToOTPModel.OTP} is your OTP for verification. Please do not share with others`, // plain text body
      html: `<b>${insertDataToOTPModel.OTP} is your OTP for verification. Please do not share with others</b>` // html body
    };

    // send mail with defined transport object
    mailConfigRef.transporter.sendMail(mailOptions, (error, info) => {
      if (error)
        {
          appConfigRef.myConsoleLog(error);
        }
        appConfigRef.myConsoleLog(`Message sent. Message Id is ${info.messageId}`);
    });
 }

// OTP sent to respective mobile number for Login the chatbot
  sendSMSOTP = function()
  {
  
    var msg=`http://api.myvaluefirst.com/psms/servlet/psms.Eservice2?data=<?xml version="1.0" encoding="ISO-8859-2"?><!DOCTYPE MESSAGE SYSTEM "http://127.0.0.1/psms/dtd/messagev12.dtd" ><MESSAGE VER="1.2"><USER USERNAME="sriramtransport" PASSWORD="ram08glob09"/><SMS UDH="0" CODING="1" TEXT="${insertDataToOTPModel.OTP} is your OTP for verification. OTP expires in 60 Sec. Please do not share with others." PROPERTY="0" ID="1"><ADDRESS FROM="SHRIRM" TO="${insertDataToOTPModel.inputValue}" SEQ="1" TAG="some clientside random data" /></SMS></MESSAGE>&action=send`;

    http.get(msg, function(res)
    {
      appConfigRef.myConsoleLog("OTP sent");
     });
  }


  exports.otpVerification=function(req,res)
  {
    var inputType;
    if((/([A-Z0-9a-z_-][^@])+?@[^$#<>?]+?\.[\w]{2,4}/.test(req.body.inputValue)))
      inputType = 'email';
    else
      inputType = 'mobileNo';
      appConfigRef.myConsoleLog(inputType);
    OTPModel.find({'inputValue':req.body.inputValue,'inputType': ((/([A-Z0-9a-z_-][^@])+?@[^$#<>?]+?\.[\w]{2,4}/.test(req.body.inputValue))) ? 'e': 'm'}).sort({createdDate: 'descending'}).limit(1).select('inputValue OTP createdDate').exec(function(err, result) { 
      if(!err)
      {
        appConfigRef.myConsoleLog(result);
       if(result.length==1)
       {
        if(req.body.OTP==result[0].OTP)
        {
          if(Math.floor(Math.abs(new Date().getTime() -  new Date(result[0].createdDate).getTime()) / (1000 * 3600 * 24))  == 0 &&  Math.abs(new Date().getTime() -  new Date(result[0].createdDate).getTime()) <= appConfigRef.OTPExpireTime)
          {
         // If given OTP is verified successfully and find the user is available or not. 

         appConfigRef.myConsoleLog("TIME CHECK")
         // sssssssssssssssss
            
            registration.find({[inputType]: req.body.inputValue}, function (err, registrationResult) {
              var sessGen=session.sessionGen();
              (registrationResult.length === 0) ? res.send('{"messageresult": {"statuscode":"00001","statusdescription":"User Not Registered"}}') : res.send('{"messageresult":{"statuscode":"00000","statusdescription":"Existing user"},"name":"' + registrationResult[0].name + '","email":"' + registrationResult[0].email + '","mobile":"' + registrationResult[0].mobileNo + '","session":"' + sessGen + '"}')+session.addBotSession(registrationResult,sessGen);
          });

          }
          else
          {
            res.json({"messageresult": {
              "statuscode": "0001",
              "statusdescription": "Your OTP is expired"
              }
            })
          }
        }
        else
          res.json({"messageresult": {
          "statuscode": "0001",
          "statusdescription": "Your OTP is invalid"
          }
        })
        }
        else{
          res.json({"messageresult": {
            "statuscode": "0001",
            "statusdescription": "Your OTP is not generated"
            }
          })
        }
       }
      else 
      appConfigRef.myConsoleLog(err);
      });
  }

  exports.sendOTPPhoneCall=function(req,res)
  {
    var inputType;
    // Here check the input type mobile number or email id
    ((/([A-Z0-9a-z_-][^@])+?@[^$#<>?]+?\.[\w]{2,4}/.test(req.body.inputValue)))?inputType = 'e':inputType = 'm';
    appConfigRef.myConsoleLog(inputType);
    if(inputType == 'm')
      {

        OTPModel.find({'inputValue':req.body.inputValue,'inputType': inputType}).sort({createdDate: 'descending'}).limit(1).select('inputValue OTP createdDate').exec(function(err,result)
          {
            if(!err)
            {
            appConfigRef.myConsoleLog(result[0].inputValue); 
            appConfigRef.myConsoleLog(result[0].OTP); 
            sendPhoneCallOTP(mailConfigRef.phoneCallUrl(result[0].inputValue,result[0].OTP));
            }
            else
            appConfigRef.myConsoleLog(err);
          })
       }
    else{
       appConfigRef.myConsoleLog("can't call");
      }
      
  }

  sendPhoneCallOTP=function(callUrl)
  {
     appConfigRef.myConsoleLog(callUrl); 
      http.get(callUrl, function(res)
      {
        appConfigRef.myConsoleLog("OTP send in phone call");
       });
  }