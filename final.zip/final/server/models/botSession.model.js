var mongoose = require('mongoose');
var botSession = new mongoose.Schema({
    name: String,
    email: String,
    mobileNo: Number,
    session: String,
    date: String,
    time: String

});


//schema creation for chatbot Response
var chat_save = new mongoose.Schema({
    api_id: String,
    intent: String,
    // Date_Time: String,
    user: String,
    bot: String,
    date: String,
    time: String,
    botSessionRef: String
})

exports.botSession = mongoose.model('botSession', botSession);
exports.ChatBot = mongoose.model('ChatBot', chat_save);