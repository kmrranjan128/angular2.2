var mongoose = require('mongoose');
var OTPSchema = new mongoose.Schema({
    inputType: String,
    inputValue: String,
    OTP: Number,
    createdDate: Date
    //Time:String
})
exports.OTPModel = mongoose.model('OTPModel', OTPSchema);