var mongoose = require('mongoose');
var config = require('../../config/dbConfig');

//schema creation for new Registration
var regist_save = new mongoose.Schema({
    name: String,
    email: {
        type: String,
        unique: true
    },
    mobileNo: {
        type: Number,
        validate: {
            validator: function (V) {
                return /\d{10}/.test(V);
            },
            message: '{VALUE} is not a valid mobile number!'
        }
    }

});

exports.Registration = mongoose.model('Registration', regist_save);