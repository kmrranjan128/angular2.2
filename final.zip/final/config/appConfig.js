var toPrint = true;
exports.myConsoleLog = function(log){
    if(toPrint)
    console.log(log);
}

exports.OTPExpireTime=120000;