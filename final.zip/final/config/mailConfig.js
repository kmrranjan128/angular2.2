var nodemailer = require('nodemailer');

var otpControllerRef=require('../server/controller/OTP.controller')
exports.fromMailId='"SVS" <svs_chatbot@shriramvalue.in>';
exports.transporter = nodemailer.createTransport({
    service: 'Rediffmail',
    host: 'smtp.rediffmailpro.com',
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
        user: 'manimozhi.b@shriramvalue.in', 
        pass: 'Mani@123'  
    }
});

// this function is used to concatenate OTP,mobile number with phone call url.This function is calling from OTP.controller.js file.
exports.phoneCallUrl=function(MobileNo,OTP)
{
    phoneCallUrl=`http://www.valuecallz.com/utils/sendVoice.php?cid=1029620&tonumber=${MobileNo}&tts_data=${OTP}`;
    return phoneCallUrl;
}