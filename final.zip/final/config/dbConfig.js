var mongoose=require('mongoose');
var url="mongodb://localhost:27017/";
var dbname="mydb";
mongoose.connect(url+dbname,{
    usemongoClient:true,
    connectTimeOut:1000
});

/* exports.mongodb='mydb'
exports.mongoport=27017
exports.http_port=8080
exports.mongourl='127.0.0.1' */