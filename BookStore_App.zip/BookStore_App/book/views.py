from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.decorators import api_view
from django.http import JsonResponse
from book.models import BookStore,Book
import os
import random
import requests
import base64
from django.db import connection
from django.db.models import Q
from base64 import decodestring
# Create your views here.
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cursor = connection.cursor()

@api_view(['POST'])
def book_insert(request):
	resp=''
	if request.method == "POST":
		try:
			ran_num = ''.join(random.choice('0123456789') for _ in range(6))
			book_info = request.data
			search_book = Book.objects.filter(book_name=book_info['book_name'])
			r = requests.get('http://127.0.0.1:8000/static/book_images/' + ran_num + '.jpg')
			path = os.path.join(BASE_DIR, 'static/book_images/')
			imgdata = base64.b64decode(str(book_info['image']))
			file_path = path + ran_num + '.jpg'
			if not search_book:
				with open(file_path, 'wb') as f:
					f.write(imgdata)
				book = Book(book_name=book_info["book_name"])
				book.save()
				book_store = BookStore(book_name=book, book_type=book_info["book_type"],
									   book_author=book_info["book_author"], book_desc=book_info["book_desc"],
									   book_pic=str(r.url))
				book_store.save()
				resp = {"status code": "100-10002", "description": "Book sucessfully saved"}


			else:
				b_name = Book.objects.get(book_name=book_info['book_name'])
				with open(file_path, 'wb') as f:
					f.write(imgdata)
				book_store = BookStore(book_name=b_name, book_type=book_info["book_type"],
									   book_author=book_info["book_author"], book_desc=book_info["book_desc"],
									   book_pic=str(r.url))
				book_store.save()
				resp = {"status code": "100-10001", "description": "Book sucessfully saved"}

		except Exception as e:
			print(e)

	return JsonResponse(resp)


	#BookStore("1",'java','')

@api_view(['GET'])
def book_edit(request):
	pass

@api_view(['POST'])
def book_delete(request):
	pass

@api_view(['POST'])
def book_update(request):
	resp = ''
	if request.method == "POST":
		book_info = request.data

		book_update = Book.objects.get(book_name=book_info['book_name'])
		if not book_update:
			print("ok")
			resp = {"status code": "100-10003", "description": "Book is not available"}
		else:
			print("wrong")
			b_update=[]
			book_id = [i for i in book_info['book_update']]
			book_name=BookStore.objects.filter(pk=book_id[0]['book_id'])
			for i in book_name:
				print("ok")
				#print(type(eval(book_id[0]['book_name'])))
				# book_store = BookStore(book_name=book_id[0]['book_name'], book_type=book_id[0]['book_type'],
				# 					   book_author=book_id[0]['book_author'], book_desc=book_id[0]['book_desc'],
				# 					   book_pic=book_id[0]['image'])
				# book_store.save()


			# 	print(i.book_name.book_name,i.book_type,i.book_author,i.book_desc,i.book_pic)
			# # 	b_update.append(i.book_name.book_name,i.book_type,i.book_author,i.book_desc,i.book_pic)
			# # print(b_update)
			# book_store = BookStore(book_name=i.book_name, book_type=i.book_type,
			# 						   book_author=i.book_author, book_desc=i.book_desc,
			# 						   book_pic=i.book_pic)
			# book_store.save()
			resp = {"status code": "100-10004", "description": "Book is not available"}
		return JsonResponse(resp)




@api_view(['GET'])
def book_search(request):

	resp=''
	b_info = []
	if request.method == "GET":
		b_search = request.GET['book']
		#book_info = request.data
		try:
			book_search = Book.objects.get(book_name=b_search)
			if not book_search:
				resp = {"status code": "100-10002", "description": "Book is not available"}
			else:
				book_data = BookStore.objects.all()
				for i in book_data:
					b_info.append({"book_id":i.book_id,"book_name":i.book_name.book_name,"book_type":i.book_type,"book_author":i.book_author,"book_desc":i.book_desc,"image":i.book_pic})
			resp={"status code": "100-10003","book_information":b_info}
		except Exception as e:
			print(e)
	return JsonResponse(resp)


@api_view(['GET'])
def book_filter(request):
	resp=''
	b_filter = []
	if request.method == "GET":
		book_info = request.data
		try:
			book_filter=Book.objects.all()
			for i in book_filter:
				b_filter.append({"book_name":i.book_name})
			resp = {"status_code": "100-10003", "book_filter": b_filter}
		except Exception as e:
			print(e)
	return JsonResponse(resp)

def home(request):
	return render(request,'home/index.html',{})
