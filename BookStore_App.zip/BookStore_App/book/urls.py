from django.urls import path
from . import views
from django.conf.urls import  include, url

urlpatterns = [
    path('', views.home, name='home'),
    path('book_save', views.book_insert, name='book_insert'),
    url(r'^book_search/$', views.book_search, name='book_insert'),

    #path('book_search/$', views.book_search, name='book_insert'),
    path('book_update', views.book_update, name='book_update'),
    path('book_filter', views.book_filter, name='book_filter'),

]