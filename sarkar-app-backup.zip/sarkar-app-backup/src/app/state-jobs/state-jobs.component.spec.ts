import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StateJobsComponent } from './state-jobs.component';

describe('StateJobsComponent', () => {
  let component: StateJobsComponent;
  let fixture: ComponentFixture<StateJobsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StateJobsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StateJobsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
