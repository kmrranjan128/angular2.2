
import {AfterViewInit, Component, ViewChild, OnInit,Input} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  image: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Andhra Pradesh', weight: 1.0079, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Andhra_pradesh_1emblem.png/100px-Andhra_pradesh_1emblem.png'},
  {position: 2, name: 'Arunachal Pradesh', weight: 4.0026, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/..Arunachal_Pradesh_Flag%28INDIA%29.png/100px-..Arunachal_Pradesh_Flag%28INDIA%29.png'},
  {position: 3, name: 'Assam', weight: 6.941, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Seal_of_Assam.svg/100px-Seal_of_Assam.svg.png'},
  {position: 4, name: 'Bihar', weight: 9.0122, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Seal_of_Bihar.svg/100px-Seal_of_Bihar.svg.png'},
  {position: 5, name: 'Chhattisgarh', weight: 10.811, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/Chhattisgarh_emblem.png/100px-Chhattisgarh_emblem.png'},
  {position: 6, name: 'Goa', weight: 12.0107, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Goa_emblem.jpg/99px-Goa_emblem.jpg'},
  {position: 7, name: 'Gujarat', weight: 14.0067, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Government_Of_Gujarat_Seal_In_All_Languages.svg/100px-Government_Of_Gujarat_Seal_In_All_Languages.svg.png'},
  {position: 8, name: 'Haryana', weight: 15.9994, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Haryana_emblem.png/99px-Haryana_emblem.png'},
  {position: 9, name: 'Himachal Pradesh', weight: 18.9984, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/Himachal_Pradesh_emblem.png/100px-Himachal_Pradesh_emblem.png'},
  {position: 10, name: 'Jharkhand', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Jharkhand_emblem.png/100px-Jharkhand_emblem.png'},
  {position: 11, name: 'Karnataka', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Seal_of_Karnataka.svg/100px-Seal_of_Karnataka.svg.png'},
  {position: 12, name: 'Kerala', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/Flag_of_Kerala.png/100px-Flag_of_Kerala.png'},
  {position: 13, name: 'Madhya Pradesh', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Madhya_Pradesh_emblem.jpg/100px-Madhya_Pradesh_emblem.jpg'},
  {position: 14, name: 'Maharashtra', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Seal_of_Maharashtra.png/100px-Seal_of_Maharashtra.png'},
  {position: 15, name: 'Manipur', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Government-of-manipur.png/99px-Government-of-manipur.png'},
  {position: 16, name: 'Meghalaya', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Seal_of_Meghalaya.svg/100px-Seal_of_Meghalaya.svg.png'},
  {position: 17, name: 'Mizoram', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Seal_of_Mizoram.svg/100px-Seal_of_Mizoram.svg.png'},
  {position: 18, name: 'Odisha', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5f/Odisha_emblem.png/99px-Odisha_emblem.png'},
  {position: 19, name: 'Punjab', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/54/Emblem-Punjab-Protocol-Manual-page98-appendix12.svg/100px-Emblem-Punjab-Protocol-Manual-page98-appendix12.svg.png'},
  {position: 20, name: 'Rajasthan', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Emblem_Rajasthan.png/100px-Emblem_Rajasthan.png'},
  {position: 21, name: 'Sikkim', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c0/Seal_of_Sikkim.svg/100px-Seal_of_Sikkim.svg.png'},
  {position: 22, name: 'Tamil Nadu', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/TamilNadu_Logo.svg/100px-TamilNadu_Logo.svg.png'},
  {position: 23, name: 'Telangana', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Emblem-of-telangana-.png/100px-Emblem-of-telangana-.png'},
  {position: 24, name: 'Tripura', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Seal_of_Tripura.svg/100px-Seal_of_Tripura.svg.png'},
  {position: 25, name: 'Uttar Pradesh', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Seal_of_Uttar_Pradesh.svg/100px-Seal_of_Uttar_Pradesh.svg.png'},
  {position: 26, name: 'Uttarakhand', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Government-of-uttarakhand-.jpg/99px-Government-of-uttarakhand-.jpg'},
  {position: 27, name: 'West Bengal', weight: 20.1797, image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Emblem_of_West_Bengal.svg/99px-Emblem_of_West_Bengal.svg.png'}
];



@Component({
  selector: 'app-state-jobs',
  templateUrl: './state-jobs.component.html',
  styleUrls: ['./state-jobs.component.css']
})
export class StateJobsComponent implements OnInit {

  displayedColumns: string[] = ['image', 'name'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
    
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor() { }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }


}
