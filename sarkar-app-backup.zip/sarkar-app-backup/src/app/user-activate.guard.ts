import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginServiceService } from "./service/login-service.service";

@Injectable({
  providedIn: 'root'
})
export class UserActivateGuard implements CanActivate {

  constructor(private loginserver :LoginServiceService){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if(this.loginserver.isAdminRight()){
      return true;
    }else{
      alert("you don't have permission..")
    }
  }
  
}
