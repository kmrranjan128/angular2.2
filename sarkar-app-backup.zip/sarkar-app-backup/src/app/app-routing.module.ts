import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from "./dashboard/dashboard.component";
import { ContactComponent } from "./contact/contact.component";
import { BodyComponent } from "./body/body.component";
import { UserActivateGuard } from './user-activate.guard';


const routes: Routes = [
  // { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '', component: BodyComponent },
  {path: 'contact',component: ContactComponent},
  {path: 'dashboard',component: DashboardComponent,canActivate:[UserActivateGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
