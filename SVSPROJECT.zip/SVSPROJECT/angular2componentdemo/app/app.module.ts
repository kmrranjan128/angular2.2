import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {HttpModule} from "@angular/http";
import {AppComponent} from "./app.component";
import {MenuComponent} from "./svsinfo.component/svsinfo.component"
import {UserService} from "./services/userService";

@NgModule({
    imports:[BrowserModule,CommonModule,HttpModule],
    declarations:[AppComponent,MenuComponent],
    providers:[UserService],
    bootstrap:[AppComponent]
})

export class AppModule{

}