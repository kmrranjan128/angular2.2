import {Injectable} from "@angular/core";
import {Http} from "@angular/http";
import 'rxjs';
@Injectable()
export class UserService{

    constructor(private http:Http){

    }

    getUserService()
    {
        return this.http.get('https://jsonplaceholder.typicode.com/users').flatMap((data)=>data.json());

    }
}