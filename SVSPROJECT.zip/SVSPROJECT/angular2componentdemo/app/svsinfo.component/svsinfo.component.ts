import {Component,OnInit,Input} from "@angular/core";
import {UserService} from "../services/userService";


@Component({
    selector:'menu-list',
    templateUrl:'./app/svsinfo.component/svsinfo.component.html',
    styleUrls:['./app/svsinfo.component/svsinfo.component.css']

})

export class MenuComponent implements OnInit{

    private menuItem:string[];
    @Input()
    finMessage:string;

    private users:any=[];
    constructor(private userService:UserService){

    }

    ngOnInit(){
        this.menuItem=["Home","About Us","Financial Services","Insurance","Ecommers","Enterprice Solution","Careers"]
    }

getService(){
   this.userService.getUserService().subscribe(response=>{
this.users.push(response);
console.log(this.users);
   });
}

}