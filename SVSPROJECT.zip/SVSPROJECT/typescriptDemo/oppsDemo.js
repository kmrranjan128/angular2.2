"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Investment;
(function (Investment) {
    var Currency = /** @class */ (function () {
        //contructor
        function Currency(name, value) {
            this.currentname = name;
            this.value = value;
        }
        return Currency;
    }());
    Investment.Currency = Currency;
    var Trader = /** @class */ (function () {
        function Trader(id, name, limit, country) {
            this.traderId = id;
            this.name = name;
            this.tradeLimit = limit;
            this.country = country;
        }
        Object.defineProperty(Trader.prototype, "tradeId", {
            set: function (value) {
                this.traderId - value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Trader.prototype, "setname", {
            set: function (value) {
                this.name = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Trader.prototype, "setcountry", {
            set: function (value) {
                this.country = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Trader.prototype, "settradeLimit", {
            set: function (value) {
                this.tradeLimit = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Trader.prototype, "getTradeId", {
            get: function () {
                return this.traderId;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Trader.prototype, "getName", {
            get: function () {
                return this.name;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Trader.prototype, "getcountry", {
            get: function () {
                return this.country;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Trader.prototype, "gettradeLimit", {
            get: function () {
                return this.tradeLimit;
            },
            enumerable: true,
            configurable: true
        });
        return Trader;
    }());
    Investment.Trader = Trader;
})(Investment = exports.Investment || (exports.Investment = {}));
/*

var  t=new Trader();
console.log(t.getName);
console.log(t.setname);
console.log(t.setcountry);
*/
/*

var tradeObj=new Trader(1234,"kumar",2121,"india");

console.log("Trade ID-->");
console.log("Trade Name-->",tradeObj.getName);
console.log("Trade Limit-->",tradeObj.gettradeLimit);
console.log("Trade country-->",tradeObj.getcountry);
*/
