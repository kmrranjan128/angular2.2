# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 17:10:12 2018

@author: admin
"""

import os;
# =============================================================================
# 
# path="D:/python_traning_1/day2";
# 
# for(dirpath.dirnames,filenames) in os.walk(path):
#     print(filenames);
#     for file in filenames:
#        (shortname,extension)=os.path.splitext(file);
#        print(extension)
#        if(extension=='.txt'):
#            contents=open(path+"/"+file,'r');
#            for line in contents:
#                print(line)
# =============================================================================


path="D:/";
for(dirpath,dirnames,filenames) in os.walk(path):
    if len(dirnames)>0:
        print(dirnames);
        for dir in dirnames:
            for(dpath,dnames,fnames) in os.walk(path+"/"+dir):
                print(fnames)
        