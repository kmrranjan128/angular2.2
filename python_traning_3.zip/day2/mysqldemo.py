# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 14:40:27 2018

@author: admin
"""
import pymysql;

def createConnection():
    conn=pymysql.connect(host="localhost",user="root",passwd="welcome@1",db="svs_python_db");
    return conn;

def addTestCaseInfo(data):
    connectObj=createConnection();
    cursor=connectObj.cursor();
    print("Cursor ready")
    #print(data);

   
                        
    

        
    try:
        cursor.execute("""insert into testcaseresults values ('%d','%s','%d')""" %(data[0],data[1],data[2]))
        connectObj.commit();
    except pymysql.Error as e:
        print("Exception occured",e);
        connectObj.rollback();
            
    #cursor.close();
    
tsData=[104541,'REQ101',1];    
    
addTestCaseInfo(tsData);


def fetchBytestCaseId(id):
    conn=createConnection()
    cursor=conn.cursor();
    cursor.execute("""select * from testcaseresults where tcno='%d'"""%(id))
    return cursor.fetchall();

rows=fetchBytestCaseId(1001)
for row in rows:
    print(row);






# =============================================================================
# 
#     try:
#       cursor.execute("""INSERT INTO testcaseresults VALUES (%d, %s, %d)""",(data[0], data[1], data[2]));
#         connectObj.commit();
#     except pymysql.Error as e:
#         print("Exception occured",e);
#         connectObj.rollback();
# =============================================================================
