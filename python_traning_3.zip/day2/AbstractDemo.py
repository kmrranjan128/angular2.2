# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 12:48:05 2018

@author: admin
"""
from abc import ABC,abstractmethod

class Logger(ABC):
    @abstractmethod
    def writeToLog(self,message):pass


class FileLogger(Logger):
     def writeToLog(self,message):
         print(message);
     def test():
         print("Testing sun class");
        
        
fileLogger=FileLogger();
fileLogger.writeToLog(8);    

    