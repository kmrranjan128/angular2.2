# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 12:18:32 2018

@author: admin
"""

import sys;
sys.path.append("D:\python_traning_1\day2");
from classdemo import PC,Locker;

class POS(PC,Locker):
    def __init__(self,no,ipaddr,vlan,bcrStatus):
        PC.__init__(self,no,ipaddr,vlan);
        self.code=0;
        self.bcrStatus=bcrStatus;
        Locker.__init__(self,id);
        
pos=POS(231,'127.0.0.1',True,True);   
print(pos.getIpAddress());   
#print(pos.lockerId);
pos.info();

 
    