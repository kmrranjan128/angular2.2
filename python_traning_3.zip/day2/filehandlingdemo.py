# -*- coding: utf-8 -*-
"""
Created on Thu Jan  4 16:48:57 2018

@author: admin
"""

import os;
# =============================================================================
# Path=r"D:\python_traning_1\day2";
# if(os.path.exists(Path)):
#     print("path Available...");
#     filepath=Path+"/demo.txt";
#     contents=open(filepath,'r');
#     for line in contents:
#         print(line);
# =============================================================================


path=r"D:\python_traning_1\day2\demo.txt";
filename="demo.txt";
if(os.path.exists(path)):
    print("path Available...");
    (shortname,extension)=os.path.splitext(filename);
    print(extension);
    if(extension=='.txt'):
        contents=open(path,'r');
        for line in contents:
            print(line);
            

