# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 15:01:31 2018

@author: admin
"""

import subprocess
host=input("Enter a host to ping :");
p1=subprocess.Popen(['ping',host], stdout=subprocess.PIPE)

output=p1.communicate()[0]
print(output);