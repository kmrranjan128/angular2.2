# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 09:55:13 2018

@author: admin

"""



import os
dirPath =r"D:\python_traning_1"
if(os.path.exists(dirPath)):
    print("Directory Exists")
else:
    subdir= input("Enter sub dir name")
    os.mkdir(dirPath+"/"+subdir, mode=0o777)
    print("directory created")

fileName=input("Enter File Name") 
dirPath=dirPath+"/"+fileName+".txt"

if(os.path.exists(dirPath)):
    print("File Exists")
    fileRef=open(dirPath,mode='a')
else:
    print("File not found")
    fileRef=open(dirPath,mode='w')
    print("File created")
    
import random
for i in range(1,100):
    fileRef.write(str(random.randint(1,1000))+"\n")
fileRef.close()
print("Contents Written")

# =============================================================================
# 
# import os;
# dirPath=r"D:/python_traning_1"
# if(os.path.exists(dirPath)):
#     print("Directive Exists");
# else:
#     subdir=input("Enter sub Dir Name");
#     os.mkdir(dirPath+"/"+subdir,mode=0o777)
#     print("Directive Created");
# fileName=input("Enter the File Name");
# dirPath=dirPath="/"+fileName+".txt"
# if(os.path.exists(dirPath)):
#     print("File Exists");
#     fileRef=open(dirPath,mode='a')
# else:
#     print("File not Found");
#     fileRef=open(dirPath,mode='w');
#     print("File Created");
# 
# import random;
# for i in range(1,100):
#     fileRef.write(str(random.randint(1,1000))+"\n")
# fileRef.close();
# print("Content Written");
# 
# =============================================================================




