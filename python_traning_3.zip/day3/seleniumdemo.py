# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 16:01:27 2018

@author: admin
"""

from selenium import webdriver

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
user = "7397283628"
pwd = "7397283628"
path="D:/python_traning_1/day3/chromedriver.exe"
driver = webdriver.Chrome(path)
driver.get("https://www.facebook.com")
assert "Facebook" in driver.title
elem = driver.find_element_by_id("email")
elem.send_keys(user)
elem = driver.find_element_by_id("pass")
elem.send_keys(pwd)
elem.send_keys(Keys.RETURN)
driver.close()


