# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 09:59:35 2018

@author: admin
"""

from openpyxl import Workbook
import calendar

filePath="D:\python_traning_1\svsexcel.xlsx";
wb=Workbook();
i=0;
for month in calendar.month_name:
        if not(len(str(month))==0):
            print(month);
            wb.create_sheet(month+"_2018",i)
i=i+1;
wb.save(filePath);        

