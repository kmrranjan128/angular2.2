# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 12:26:15 2018

@author: admin
"""

import requests

response=requests.get("http://jsonplaceholder.typicode.com/users")
user=[]
for obj in response.json():
    print(obj['username'],'\t',obj['email'],'\t',
          obj['address']['city'],'\t',
          obj['address']['geo']['lat'])
    
    
directionData=requests.get("https://maps.googleapi.com/map/api/directions/json?original=Bangalore&destination=Pune",verify=False)
print(directionData.json()['routers'][0]['bounds']);
    
