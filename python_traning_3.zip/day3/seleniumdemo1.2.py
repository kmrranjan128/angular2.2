# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 16:49:15 2018

@author: admin
"""

import re

regex=r"[A-z]{1,2}[0-9R][0-9A-Z]? [0-9][ABC-HJLNP-UW-Z]{2}"
address="BBC New Center,London, W12 7RJ"
compiled_re=re.compile(regex);
res=compiled_re.search(address)
print(res);


#os.walk

#https://github.com/eswaribala/citrix_pythontraining