# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 12:51:46 2018

@author: admin
"""

from flask import Flask
app=Flask(__name__)

@app.route('/test')
def welcome():
    return '<h1 style="color:red">Welcome to Shriram Value Service</h1>'
if __name__ == '__main__':
    app.run(host='127.0.0.1',
            port=int("5000")
            )
