# -*- coding: utf-8 -*-
"""
Created on Fri Jan  5 11:49:19 2018

@author: admin
"""


from openpyxl import load_workbook
from openpyxl.styles import Font,Fill
from openpyxl.styles.colors import BLUE

import random

filePath="D:\python_traning_1\svsexcel.xlsx";
fileRef=load_workbook(filePath,read_only=False)
sheetNames=fileRef.get_sheet_names();
print(sheetNames);
sheet=fileRef.get_sheet_by_name('January_2018');
# =============================================================================
# for row in range(51,100):
#     for col in range(1,6):
#         sheet.cell(column=col,row=row,value="%d" % random.randint(1,10000))
# fileRef.save(filePath);        
# =============================================================================
c=sheet['A1'];
c.font=Font(size=48,color=BLUE)
for row in range(51,100):
     for col in range(1,6):
         sheet.cell(column=col,row=row,value="%d" % random.randint(1,10000))
fileRef.save(filePath);



