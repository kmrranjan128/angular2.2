# -*- coding: utf-8 -*-
"""
Created on Wed Jan  3 14:18:21 2018

@author: admin
"""
courseName="python";
#first letter converted to upper case
print(courseName.capitalize());

#center the string with filler
print(courseName.center(len(courseName)+20,'|'));
#left justification
print(courseName.ljust(len(courseName)+20,'|'));

#right justification
amount="4300000";
print(amount.rjust(len(amount)+20,'|'));

#encoding and decoding with base 64 conversion

import base64;
sequenceNo='123';
#data=sequenceNo[2:4];
#print(data);


pnrNo=base64.b64encode(str(sequenceNo).encode(encoding='utf-8',errors='strict'));

for _ in pnrNo[0:]:
   print(chr(int(_)),end='');

#print(pnrNo);
print('\n')
data=base64.b64decode(pnrNo).decode(encoding='utf-8',errors='strict');
print(data);

print(len(data));



