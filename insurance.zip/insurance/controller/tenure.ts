import {SchemesDeposit} from "./schemeDeposit";

class Tenure extends SchemesDeposit{

static roi:number=7.5;




}
 var s=new SchemesDeposit();
var s1=new Tenure();
s.setId=1;
s.setName="ranjan";
console.log(s.getId);
console.log(s.getName);

