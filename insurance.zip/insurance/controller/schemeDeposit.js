"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SchemesDeposit = /** @class */ (function () {
    function SchemesDeposit() {
    }
    Object.defineProperty(SchemesDeposit.prototype, "setId", {
        /* constructor(id:number,name:string){
             this.id=id;
             this.name=name;
         }*/
        set: function (value) {
            this.id = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SchemesDeposit.prototype, "setName", {
        set: function (value) {
            this.name = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SchemesDeposit.prototype, "getId", {
        get: function () {
            return this.id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SchemesDeposit.prototype, "getName", {
        get: function () {
            return this.name;
        },
        enumerable: true,
        configurable: true
    });
    return SchemesDeposit;
}());
exports.SchemesDeposit = SchemesDeposit;
var scheme = new SchemesDeposit();
scheme.setId = 2;
scheme.setName = "kumar";
console.log(scheme.getId);
console.log(scheme.getName);
