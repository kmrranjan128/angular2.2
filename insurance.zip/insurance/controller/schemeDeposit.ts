export class SchemesDeposit{

    private id:number;
    private name:string;

   /* constructor(id:number,name:string){
        this.id=id;
        this.name=name;
    }*/
    set setId(value:number){
     this.id=value;
    }
    set setName(value:string){
        this.name=value;
    }
    get getId():number{
        return this.id;
    }
get getName():string{
        return this.name;
}
}
var scheme=new SchemesDeposit();
scheme.setId=2;
scheme.setName="kumar";



console.log(scheme.getId);
console.log(scheme.getName);
