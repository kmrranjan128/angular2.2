"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var schemeDeposit_1 = require("./schemeDeposit");
var Tenure = /** @class */ (function (_super) {
    __extends(Tenure, _super);
    function Tenure() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Tenure.roi = 7.5;
    return Tenure;
}(schemeDeposit_1.SchemesDeposit));
var s = new schemeDeposit_1.SchemesDeposit();
var s1 = new Tenure();
s.setId = 1;
s.setName = "ranjan";
console.log(s.getId);
console.log(s.getName);
