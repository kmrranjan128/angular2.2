abstract class Logger{
    abstract writeToLog(message:string);
}

export class FileLogger extends Logger{

    writeToLog(message:string):void{
        console.log("Log Message Will be loggerd in File","---->",message);
    }
}
 export class TicketLogger extends Logger{
    writeToLog(message:string):void{
        console.log("Raise Ticket... critical error ");
    }
 }