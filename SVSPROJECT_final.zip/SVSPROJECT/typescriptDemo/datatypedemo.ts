
function customerData(customerid:number,customerName:string,countryName:string="India"):void{

    console.log(customerid,"-->",customerName,"-->",countryName)

}

customerData( 1,"kumar")


/*
function skillReport(name:string,...skillSet:string[][]){
skillSet.forEach((obj)=>{
    console.log(obj)

})
}
skillReport(name"kumar");
skillReport(name:"Ranjan",skillSet:"java","C#");
var skills1:string[]=["java","spring"];
var skills2:string[]=["java","spring","web service"];
skillReport(name:"john",skills1,skills2);*/





/*



var schenmeName:string;
var tenure:number;
var roi:number;

schenmeName="NTSE";
tenure=10;
roi=3.4;


console.log(name);

console.log(schenmeName,"--->",tenure,"---->",roi);

//Enum Data
enum gender{
    MALE,FEMALE
}
var genderType:gender;
genderType=gender.MALE;

var info:any[]=["kumar",26,"05/08/1993",true];
// arrow function

info.forEach((obj)=>{
    console.log(obj)

}
*/

// default parameter
