var Test = /** @class */ (function () {
    function Test() {
    }
    Object.defineProperty(Test.prototype, "setId", {
        set: function (value) {
            this.id = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Test.prototype, "getId", {
        get: function () {
            return this.id;
        },
        enumerable: true,
        configurable: true
    });
    return Test;
}());
var t = new Test();
t.setId = 1;
console.log(t.getId);
