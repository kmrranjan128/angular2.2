var message = { messageId: 1234, description: "ingo" };
console.log(message);
