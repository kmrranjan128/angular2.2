interface Message{
    messageId:number;
    description:string;
}

var message:Message={messageId:1234,description:"ingo"};
console.log(message);