import {Investment} from "./oppsDemo";

class privilegedTrade extends  Investment.Trader{

    private ceiling:boolean;
    static orgName:string;

    constructor(id:number,name:string,limit:number,country:string,ceiling:boolean){
        super(id,name,limit,country);
        this.ceiling=ceiling;
    }

}

var privilegTrade=new privilegedTrade(12,"kumar",1234,"india",false);
console.log(privilegTrade.getName,privilegTrade.gettradeLimit,privilegTrade.getcountry,privilegTrade.getTradeId);
privilegedTrade.orgName="SVS";
console.log(privilegedTrade.orgName)