import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {HttpModule} from "@angular/http";
import {AppComponent} from "./app.component";
import {MenuComponent} from "./svsinfo.component/svsinfo.component"
import {UserService} from "./services/userService";
import {RouterModule} from "@angular/router";
import {CountryComponent} from "./country/country.component";
import {AppRoutingModule} from "./app-routing.module";
import {FinancialComponent} from "./finance/finance.component";
import {OPECService} from "./services/mockService";
import {HighLightComponent} from "./directive/directive.component";
import {CountryNamePipe} from "./filters/filter.component";
import {RegisterComponent} from "./forms/form.register.component";
import {LoginComponent} from "./forms/forms.login.component";
import {ReactiveFormsModule,FormsModule} from "@angular/forms";
import {EqualValidator} from "./forms/matchValidator";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
    imports:[BrowserModule,BrowserAnimationsModule,CommonModule,HttpModule,AppRoutingModule,ReactiveFormsModule,FormsModule],
    declarations:[AppComponent,MenuComponent,CountryComponent,FinancialComponent,HighLightComponent,CountryNamePipe,RegisterComponent,LoginComponent,EqualValidator],
    providers:[UserService,OPECService],
    bootstrap:[AppComponent]
})

export class AppModule{

}