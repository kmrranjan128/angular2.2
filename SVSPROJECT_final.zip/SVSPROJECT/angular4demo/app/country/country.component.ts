import {Component, HostBinding, OnInit} from "@angular/core"
import {UserService} from "../services/userService";
import {ROUND_ANTICLOCK_ANIMATION} from "../animations/round-anticlock.animation";

@Component({
    templateUrl:'./app/country/country.component.html',
    styleUrls:['./app/country/country.component.css'],
    animations:[
        ROUND_ANTICLOCK_ANIMATION
    ]


})

export class CountryComponent implements OnInit{
 @HostBinding('@roundAntiClockTrigger') roundAntiClockTrigger = 'in';
    private countries:any=[];
    private filterChar:string='A';

    constructor(private userService:UserService){



    }

    ngOnInit(){
      this.userService.getuserInfo().subscribe(response=>{
          this.countries.push(response);
          console.log(this.countries);


      })
    }



}