import {Component, OnInit} from "@angular/core"
import {UserService} from "../services/userService";

@Component({
    templateUrl:'./app/country/country.component.html',
    styleUrls:['./app/country/country.component.css']

})

export class CountryComponent implements OnInit{

    private countries:any=[];
    private filterChar:string='A';

    constructor(private userService:UserService){



    }

    ngOnInit(){
      this.userService.getuserInfo().subscribe(response=>{
          this.countries.push(response);
          console.log(this.countries);


      })
    }



}