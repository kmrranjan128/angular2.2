import { NgModule }      from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {CountryComponent} from "./country/country.component";
import {FinancialComponent} from "./finance/finance.component";
import {RegisterComponent} from "./forms/form.register.component";
import {LoginComponent} from "./forms/forms.login.component";


const routes: Routes = [
	{
	   path: 'aboutus',
	   component: CountryComponent,
        outlet:'aboutusOutlet'
	},
    {
	   path: 'finService',
	   component: FinancialComponent,
        outlet:'finOutlet'
	},
     {
	   path: 'register',
	   component: RegisterComponent,

	},

	{
	   path: 'login',
	   component: LoginComponent,

	}
];
@NgModule({
  imports: [
          RouterModule.forRoot(routes)
  ],
  exports: [
          RouterModule
  ]
})
export class AppRoutingModule{ }