"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var MenuComponent = /** @class */ (function () {
    function MenuComponent() {
    }
    MenuComponent.prototype.ngOnInit = function () {
        this.menuItem = ["Home", "About Us", "Financial Services", "Insurance", "Ecommers", "Enterprice Solution", "Careers"];
    };
    __decorate([
        core_1.Input()
    ], MenuComponent.prototype, "finMessage", void 0);
    MenuComponent = __decorate([
        core_1.Component({
            selector: 'menu-list',
            templateUrl: './app/svsinfo.component/svsinfo.component.html',
            styleUrls: ['./app/svsinfo.component/svsinfo.component.css']
        })
    ], MenuComponent);
    return MenuComponent;
}());
exports.MenuComponent = MenuComponent;
