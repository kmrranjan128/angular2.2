depositeApp.controller('schemesController',['$scope',function ($scope) {
    $scope.schemeObj={
        schemesName:"",
        tenure:0,
        roi:0.0
    }
$scope.schemeObj.save=function () {
    console.log($scope.schemeObj.schemesName,"-->",$scope.schemeObj.tenure,"--->",$scope.schemeObj.roi);
}
}])