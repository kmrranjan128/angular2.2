from django.db import models


# Create your models here.

class SignUp(models.Model):
    name = models.CharField(max_length=100)
    mobile = models.CharField(max_length=10, unique=True)
    email = models.CharField(max_length=100, unique=True)
    userpwd = models.CharField(max_length=50)

    # created_on = models.DateTimeField(auto_now_add=True)

    # def set_name(self, name):
    #     self.name = name

    # def get_name(self):
    #     return self.name

    # def set_mobile(self, mobile_number):
    #     self.mobile_number = mobile_number

    # def get_mobile(self):
    #     return self.mobile_number

    # def set_email(self, email):
    #     self.email = email

    # def get_email(self):
    #     return self.email

    # def set_address(self, address):
    #     self.address = address

    # def get_address(self):
    #     return self.address
