from django.shortcuts import render
from django.template import loader

from django.views.decorators.csrf import csrf_exempt

from django.http import StreamingHttpResponse
import json
from django.http import HttpResponse
from registration.models import SignUp
from django.http import JsonResponse



#importing loading from django template
from django.template import loader

#our view which is a function named index


@csrf_exempt
def signup_save(request):
	response=''
	if request.method == 'POST':
		print(request.POST['name'])
		try:
			if SignUp.objects.filter(mobile=request.POST['mobile']):
				response={"statuscode": "100-0001", "statusmessage": "Your mobile number already registered"}
			elif SignUp.objects.filter(email=request.POST['email']):
				response={"statuscode": "100-0002", "statusmessage": "Your email already registered"}
			else:
				SignUp.objects.create(name = request.POST['name'],mobile = request.POST['mobile'],email = received_json_data['email'],userpwd=received_json_data['password'])
				response={"statuscode": "100-0003", "statusmessage": "Successfully registered"}
		except Exception as e:
			response={"statuscode": "100-0004", "statusmessage": "internal server error"}
	else:
		response={"statuscode": "100-0005", "statusmessage": "Method not allowed"}
	return JsonResponse(response)


@csrf_exempt
def login(request):
	response=''
	if request.method == 'POST':
		received_json_data=json.loads(request.body)
		try:
			username = SignUp.objects.get(mobile=received_json_data['userID'],userpwd=received_json_data['password'])
			#print(username.name)
			response={"statuscode": "100-0006","username":username.name, "statusmessage": "Login successfully"}
		except Exception as e:
			response={"statuscode": "100-0007", "statusmessage": "Invalid userID/password"}
	else:
		response={"statuscode": "100-0005", "statusmessage": "Method not allowed"}
	return JsonResponse(response)
