$("#post-btn").click(function(){        
   console.log($('#name').val())
   $.ajax({
   		type: "POST",
        url: 'http://localhost:8000/signup/',
        data: {"name":"Ranjan","mobile":"7598160942","email":"kmrranjan128@gmail.com","password":"12345"},
        dataType: 'json',
        success: function (data) {
         
            alert(data.statusmessage);
         
        }
      });

});