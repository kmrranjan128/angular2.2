var mysqlRef=require('mysql');
var dbConfigRef=require('./dbConfig');
var connection=mysqlRef.createConnection({
    host:dbConfigRef.host,
    user:dbConfigRef.user,
    password:dbConfigRef.password,
    database:dbConfigRef.config_database
});

connection.connect();
console.log("connected");
var queryString='select *from customer';
var inserCustomer='insert into customer(CUSTOMER_ID,NAME,DOB)values(?,?,?)';
var updateCustomer="UPDATE customer SET NAME='Mannu' WHERE CUSTOMER_ID=1";
var deleteCustomer="DELETE FROM customer WHERE customer_id=8";


exports.getCustomerList=function(){
    return new Promise(function (resolve,reject) {
        connection.query(queryString,function (err,rows,fields) {

            if(err)
                return reject(err)
            else
                return resolve(rows)
        })
    });
}

// insert

var data=[8,'Arun','1992/02/02'];

exports.getAddCustomer=function(){
    return new Promise(function (resolve,reject) {
        connection.query(inserCustomer,data,function (err,rows,fields) {

            if(err)
                return reject(err)
            else
                return resolve(rows)
        })
    });
}


//update

exports.getUpdateCustomer=function(){
    return new Promise(function (resolve,reject) {
        connection.query(updateCustomer,function (err,rows,fields) {

            if(err)
                return reject(err)
            else
                return resolve(rows)
        })
    });
}

//Delete

exports.getDeleteCustomer=function(){
    return new Promise(function (resolve,reject) {
        connection.query(deleteCustomer,function (err,rows,fields) {

            if(err)
                return reject(err)
            else
                return resolve(rows)
        })
    });
}












// select Query
/*connection.query(queryString,function (err,rows,fields) {
    if(err)
        console.log("could not connect to table");
    else
        console.log(rows);
    //console.log(fields)
});*/

//insert Query
/*
var inserCustomer='insert into customer(CUSTOMER_ID,NAME,DOB)values(?,?,?)';
var data=[4,'Ravi','1992/02/02'];
connection.query(inserCustomer,data,function (err) {

    if(err)
        console.log(err)
    else
        console.log("customer Added...");

})*/

// update Query
/*
var updateCustomer="UPDATE customer SET NAME='Rajan' WHERE CUSTOMER_ID=3";
connection.query(updateCustomer,function (err) {

    if(err)
        console.log(err)
    else
        console.log("customer uPDATE...");

})*/

// dalete Query

/*
var deleteCustomer="DELETE FROM customer WHERE customer_id=3";
connection.query(deleteCustomer,function (err) {

    if(err)
        console.log(err)
    else
        console.log("customer delete...");

})
*/
