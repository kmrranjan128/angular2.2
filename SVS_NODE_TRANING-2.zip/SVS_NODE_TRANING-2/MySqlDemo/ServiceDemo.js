var fnRef=require('./connectiontest');
//select
fnRef.getCustomerList().then(function(rows) {
    console.log(rows);
}).catch()


//insert
/*fnRef.getAddCustomer().then(function(rows) {
    console.log(rows);
}).catch()*/

//update
fnRef.getUpdateCustomer().then(function(rows) {
    console.log(rows);
}).catch()

//delete
fnRef.getDeleteCustomer().then(function(rows) {
    console.log(rows);
}).catch()

