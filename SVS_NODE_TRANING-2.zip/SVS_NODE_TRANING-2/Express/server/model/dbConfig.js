exports.port=3306
exports.host='localhost'
exports.user='root'
exports.password='welcome@1'
exports.config_database='svs_db'