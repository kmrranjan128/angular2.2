var expressRef=require('express');
var fnRef=require('../model/connectiontest');
var bodyParse=require('body-parser')
var app=new expressRef();

app.use(bodyParse.urlencoded({ extended: false }));
app.use(bodyParse.json());



app.get('/',function (req,res) {
    res.send("API path is up.....");
})

app.use('/images',expressRef.static('../../resources'))


app.get('/getCustomer',function (req,res) {

    //select
    fnRef.getCustomerList().then(function(rows) {
        res.send(rows);
    }).catch()


})

//post

app.post('/addCustomer',function (req,res) {
    //var data=[req.body.id,req.body.name,req.body.dob];
   var data=[106,'Manish','1992/02/02'];
    console.log(data)
    fnRef.getAddCustomer(data).then(function(info) {
        //console.log(res)
        res.send(info);

    },function (error) {
        res.send("{invalid...}");
    }).catch()

//res.send("welcome to shriram value Service");

})



var port=8080;
app.listen(port,function () {
    console.log("server listening on port http://localhost:",+port);
});



//select
/*fnRef.getCustomerList().then(function(rows) {
    console.log(rows);
}).catch()*/


//insert
/*
fnRef.getAddCustomer().then(function(rows) {
    console.log(rows);
}).catch()
*/

//update
/*fnRef.getUpdateCustomer().then(function(rows) {
    console.log(rows);
}).catch()

//delete
fnRef.getDeleteCustomer().then(function(rows) {
    console.log(rows);
}).catch()*/

